// packages/shared/src/types/index.ts
// Shared types used across frontend and backend

export type ReleaseStatus = 'draft' | 'pending' | 'processing' | 'approved' | 'rejected' | 'distributed' | 'takedown';
export type ReleaseType = 'single' | 'ep' | 'album' | 'compilation';
export type UserRole = 'admin' | 'artist' | 'label';
export type UploadType = 'audio' | 'artwork' | 'avatar' | 'logo' | 'document';

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}

export interface ApiUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  displayName: string;
  avatarUrl?: string;
  role: { name: UserRole };
  isEmailVerified: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ApiRelease {
  id: string;
  userId: string;
  title: string;
  type: ReleaseType;
  status: ReleaseStatus;
  releaseDate?: string;
  artworkUrl?: string;
  artworkS3Key?: string;
  labelName?: string;
  upc?: string;
  genre?: string;
  subgenre?: string;
  language?: string;
  territories: string[];
  distributionPlatforms: string[];
  submissionNotes?: string;
  adminNotes?: string;
  rejectedReason?: string;
  submittedAt?: string;
  reviewedAt?: string;
  distributedAt?: string;
  songs?: ApiSong[];
  user?: ApiUser;
  createdAt: string;
  updatedAt: string;
}

export interface ApiSong {
  id: string;
  releaseId: string;
  userId: string;
  title: string;
  artistName: string;
  featuredArtists: string[];
  composer?: string;
  producer?: string;
  lyricist?: string;
  genre?: string;
  language?: string;
  isrc?: string;
  durationSeconds?: number;
  trackNumber: number;
  isExplicit: boolean;
  bpm?: number;
  audioUrl?: string;
  audioS3Key?: string;
  audioFormat?: string;
  audioSizeBytes?: number;
  audioBitrate?: number;
  audioSampleRate?: number;
  createdAt: string;
  updatedAt: string;
}

export interface ApiBranding {
  id: string;
  platformName: string;
  tagline?: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  fontHeading: string;
  fontBody: string;
  customCss?: string;
  footerText?: string;
  supportEmail?: string;
  supportUrl?: string;
  termsUrl?: string;
  privacyUrl?: string;
  socialLinks: Record<string, string>;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ApiSetting {
  id: string;
  key: string;
  value: string | null;
  isEncrypted: boolean;
  category: string;
  description?: string;
  updatedAt: string;
}

export interface PresignedUploadResponse {
  uploadUrl: string;
  key: string;
  bucket: string;
  expiresAt: string;
  publicUrl: string;
}

export interface ReleaseStats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  distributed: number;
}

export interface AdminOverview {
  users: {
    total: number;
    active: number;
    newThisMonth: number;
  };
  releases: {
    total: number;
    pending: number;
    approved: number;
    rejected: number;
    distributed: number;
  };
  songs: { total: number };
  recentReleases: ApiRelease[];
}

export const DISTRIBUTION_PLATFORMS = [
  { id: 'spotify', name: 'Spotify', color: '#1DB954' },
  { id: 'apple_music', name: 'Apple Music', color: '#FC3C44' },
  { id: 'youtube_music', name: 'YouTube Music', color: '#FF0000' },
  { id: 'tiktok', name: 'TikTok', color: '#010101' },
  { id: 'deezer', name: 'Deezer', color: '#A238FF' },
  { id: 'amazon_music', name: 'Amazon Music', color: '#25D1DA' },
  { id: 'pandora', name: 'Pandora', color: '#005AA5' },
  { id: 'tidal', name: 'TIDAL', color: '#000000' },
  { id: 'soundcloud', name: 'SoundCloud', color: '#FF5500' },
  { id: 'boomplay', name: 'Boomplay', color: '#EC0A17' },
] as const;

export const GENRES = [
  'Afrobeats', 'Afropop', 'Amapiano', 'Blues', 'Classical', 'Country',
  'Dance', 'Electronic', 'Folk', 'Funk', 'Gospel', 'Hip-Hop', 'House',
  'Indie', 'Jazz', 'Latin', 'Metal', 'Pop', 'R&B', 'Reggae', 'Rock',
  'Soul', 'Trap', 'World', 'Other',
] as const;

export const LANGUAGES = [
  'English', 'Spanish', 'French', 'Portuguese', 'Arabic', 'Mandarin',
  'Yoruba', 'Igbo', 'Hausa', 'Swahili', 'Zulu', 'Amharic',
  'Hindi', 'Korean', 'Japanese', 'German', 'Italian', 'Other',
] as const;
