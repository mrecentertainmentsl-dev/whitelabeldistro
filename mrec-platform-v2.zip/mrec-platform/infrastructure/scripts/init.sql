-- MREC Platform Database Schema
-- White-label Music Distribution Platform

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================
-- ROLES
-- =====================
CREATE TABLE roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(50) UNIQUE NOT NULL,
  description TEXT,
  permissions JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO roles (name, description, permissions) VALUES
  ('admin', 'Platform administrator', '["*"]'),
  ('artist', 'Music artist or label', '["upload", "view_own", "manage_own"]'),
  ('label', 'Record label account', '["upload", "view_own", "manage_own", "manage_sub_artists"]');

-- =====================
-- USERS
-- =====================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  display_name VARCHAR(150),
  avatar_url TEXT,
  role_id UUID REFERENCES roles(id) DEFAULT (SELECT id FROM roles WHERE name = 'artist'),
  is_active BOOLEAN DEFAULT true,
  is_email_verified BOOLEAN DEFAULT false,
  email_verification_token VARCHAR(255),
  email_verification_expires TIMESTAMP,
  password_reset_token VARCHAR(255),
  password_reset_expires TIMESTAMP,
  two_factor_enabled BOOLEAN DEFAULT false,
  two_factor_secret VARCHAR(255),
  last_login_at TIMESTAMP,
  login_count INTEGER DEFAULT 0,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role_id ON users(role_id);

-- =====================
-- ARTISTS
-- =====================
CREATE TABLE artists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  stage_name VARCHAR(200) NOT NULL,
  bio TEXT,
  country VARCHAR(100),
  genres TEXT[],
  spotify_id VARCHAR(100),
  apple_music_id VARCHAR(100),
  social_links JSONB DEFAULT '{}',
  is_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_artists_user_id ON artists(user_id);

-- =====================
-- RELEASES
-- =====================
CREATE TYPE release_type AS ENUM ('single', 'ep', 'album', 'compilation');
CREATE TYPE release_status AS ENUM ('draft', 'pending', 'processing', 'approved', 'rejected', 'distributed', 'takedown');

CREATE TABLE releases (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  artist_id UUID REFERENCES artists(id),
  title VARCHAR(500) NOT NULL,
  type release_type DEFAULT 'single',
  status release_status DEFAULT 'draft',
  release_date DATE,
  artwork_url TEXT,
  artwork_s3_key TEXT,
  label_name VARCHAR(200),
  upc VARCHAR(50),
  catalog_number VARCHAR(100),
  copyright_year INTEGER,
  copyright_holder VARCHAR(200),
  genre VARCHAR(100),
  subgenre VARCHAR(100),
  language VARCHAR(50),
  territories TEXT[] DEFAULT ARRAY['worldwide'],
  distribution_platforms TEXT[] DEFAULT ARRAY[]::TEXT[],
  submission_notes TEXT,
  admin_notes TEXT,
  rejected_reason TEXT,
  submitted_at TIMESTAMP,
  reviewed_at TIMESTAMP,
  reviewed_by UUID REFERENCES users(id),
  distributed_at TIMESTAMP,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_releases_user_id ON releases(user_id);
CREATE INDEX idx_releases_status ON releases(status);
CREATE INDEX idx_releases_artist_id ON releases(artist_id);

-- =====================
-- SONGS / TRACKS
-- =====================
CREATE TABLE songs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  release_id UUID REFERENCES releases(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(500) NOT NULL,
  artist_name VARCHAR(500) NOT NULL,
  featured_artists TEXT[],
  composer VARCHAR(500),
  producer VARCHAR(500),
  lyricist VARCHAR(500),
  genre VARCHAR(100),
  subgenre VARCHAR(100),
  language VARCHAR(50),
  isrc VARCHAR(20),
  duration_seconds INTEGER,
  track_number INTEGER DEFAULT 1,
  disc_number INTEGER DEFAULT 1,
  is_explicit BOOLEAN DEFAULT false,
  bpm INTEGER,
  key_signature VARCHAR(20),
  lyrics TEXT,
  audio_url TEXT,
  audio_s3_key TEXT,
  audio_format VARCHAR(10),
  audio_size_bytes BIGINT,
  audio_bitrate INTEGER,
  audio_sample_rate INTEGER,
  waveform_data JSONB,
  preview_start_seconds INTEGER DEFAULT 0,
  status release_status DEFAULT 'draft',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_songs_release_id ON songs(release_id);
CREATE INDEX idx_songs_user_id ON songs(user_id);
CREATE INDEX idx_songs_isrc ON songs(isrc);

-- =====================
-- UPLOADS (tracking)
-- =====================
CREATE TYPE upload_type AS ENUM ('audio', 'artwork', 'document', 'avatar', 'logo');
CREATE TYPE upload_status AS ENUM ('pending', 'processing', 'completed', 'failed');

CREATE TABLE uploads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  type upload_type NOT NULL,
  original_filename VARCHAR(500),
  s3_key TEXT NOT NULL,
  s3_bucket VARCHAR(200),
  s3_region VARCHAR(50),
  mime_type VARCHAR(100),
  size_bytes BIGINT,
  status upload_status DEFAULT 'pending',
  processing_error TEXT,
  metadata JSONB DEFAULT '{}',
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_uploads_user_id ON uploads(user_id);
CREATE INDEX idx_uploads_s3_key ON uploads(s3_key);

-- =====================
-- DOMAINS (white-label)
-- =====================
CREATE TABLE domains (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  domain VARCHAR(500) UNIQUE NOT NULL,
  branding_id UUID,
  is_primary BOOLEAN DEFAULT false,
  is_verified BOOLEAN DEFAULT false,
  verification_token VARCHAR(255),
  ssl_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- =====================
-- BRANDING / WHITE LABEL
-- =====================
CREATE TABLE branding (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  platform_name VARCHAR(200) NOT NULL DEFAULT 'MREC Entertainment',
  tagline VARCHAR(500),
  logo_url TEXT,
  logo_s3_key TEXT,
  favicon_url TEXT,
  favicon_s3_key TEXT,
  primary_color VARCHAR(7) DEFAULT '#7C3AED',
  secondary_color VARCHAR(7) DEFAULT '#A855F7',
  accent_color VARCHAR(7) DEFAULT '#F59E0B',
  background_color VARCHAR(7) DEFAULT '#0F0F0F',
  text_color VARCHAR(7) DEFAULT '#FFFFFF',
  font_heading VARCHAR(100) DEFAULT 'Inter',
  font_body VARCHAR(100) DEFAULT 'Inter',
  custom_css TEXT,
  footer_text TEXT,
  support_email VARCHAR(255),
  support_url TEXT,
  terms_url TEXT,
  privacy_url TEXT,
  social_links JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  domain_id UUID REFERENCES domains(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Link domains to branding
ALTER TABLE domains ADD CONSTRAINT fk_domain_branding FOREIGN KEY (branding_id) REFERENCES branding(id);

-- Insert default branding
INSERT INTO branding (platform_name, tagline, primary_color, secondary_color, accent_color, is_active)
VALUES ('MREC Entertainment', 'Distribute Your Music Globally', '#7C3AED', '#A855F7', '#F59E0B', true);

-- =====================
-- SETTINGS
-- =====================
CREATE TABLE settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key VARCHAR(200) UNIQUE NOT NULL,
  value TEXT,
  encrypted_value TEXT,
  is_encrypted BOOLEAN DEFAULT false,
  category VARCHAR(100),
  description TEXT,
  updated_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Default settings
INSERT INTO settings (key, value, category, description) VALUES
  ('aws_s3_bucket', '', 'storage', 'AWS S3 Bucket Name'),
  ('aws_s3_region', 'us-east-1', 'storage', 'AWS S3 Region'),
  ('aws_ses_region', 'us-east-1', 'email', 'AWS SES Region'),
  ('max_file_size_mb', '500', 'upload', 'Maximum file size in MB'),
  ('allowed_audio_formats', '["wav","flac"]', 'upload', 'Allowed audio formats'),
  ('allowed_image_formats', '["jpg","jpeg","png"]', 'upload', 'Allowed image formats'),
  ('min_artwork_width', '3000', 'upload', 'Minimum artwork width in pixels'),
  ('min_artwork_height', '3000', 'upload', 'Minimum artwork height in pixels'),
  ('distribution_platforms', '["spotify","apple_music","youtube_music","tiktok","deezer"]', 'distribution', 'Available distribution platforms'),
  ('require_isrc', 'false', 'distribution', 'Require ISRC for all tracks'),
  ('auto_approve', 'false', 'admin', 'Auto-approve releases without admin review'),
  ('registration_enabled', 'true', 'auth', 'Allow new user registration'),
  ('email_verification_required', 'true', 'auth', 'Require email verification');

-- =====================
-- ADMIN LOGS
-- =====================
CREATE TYPE log_level AS ENUM ('info', 'warning', 'error', 'success');

CREATE TABLE admin_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id UUID REFERENCES users(id),
  action VARCHAR(200) NOT NULL,
  entity_type VARCHAR(100),
  entity_id UUID,
  old_value JSONB,
  new_value JSONB,
  ip_address INET,
  user_agent TEXT,
  level log_level DEFAULT 'info',
  message TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_admin_logs_admin_id ON admin_logs(admin_id);
CREATE INDEX idx_admin_logs_entity ON admin_logs(entity_type, entity_id);
CREATE INDEX idx_admin_logs_created_at ON admin_logs(created_at);

-- =====================
-- NOTIFICATIONS
-- =====================
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(300) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(50) DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  action_url TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);

-- =====================
-- DISTRIBUTION TARGETS
-- =====================
CREATE TABLE distribution_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  release_id UUID REFERENCES releases(id) ON DELETE CASCADE,
  platform VARCHAR(100) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  platform_release_id VARCHAR(255),
  platform_url TEXT,
  submitted_at TIMESTAMP,
  live_at TIMESTAMP,
  error_message TEXT,
  response_data JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- =====================
-- SUBSCRIPTIONS (future billing)
-- =====================
CREATE TABLE subscription_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price_monthly DECIMAL(10,2),
  price_yearly DECIMAL(10,2),
  features JSONB DEFAULT '{}',
  max_releases INTEGER,
  max_songs INTEGER,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

-- =====================
-- UPDATED_AT TRIGGERS
-- =====================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_releases_updated_at BEFORE UPDATE ON releases FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_songs_updated_at BEFORE UPDATE ON songs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_uploads_updated_at BEFORE UPDATE ON uploads FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_branding_updated_at BEFORE UPDATE ON branding FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_settings_updated_at BEFORE UPDATE ON settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_artists_updated_at BEFORE UPDATE ON artists FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Default admin user (password: Admin@123456 - change in production)
INSERT INTO users (email, password_hash, first_name, last_name, role_id, is_email_verified, is_active)
VALUES (
  'admin@mrec.io',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQyCgavRyJ2fxqcXIYrdkMPLy',
  'Platform',
  'Admin',
  (SELECT id FROM roles WHERE name = 'admin'),
  true,
  true
);
