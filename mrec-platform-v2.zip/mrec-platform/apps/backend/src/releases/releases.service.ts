import {
  Injectable, NotFoundException, ForbiddenException,
  BadRequestException, Logger
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindManyOptions } from 'typeorm';
import { Release, ReleaseStatus } from './entities/release.entity';
import { Song } from './entities/song.entity';
import { User } from '../users/entities/user.entity';
import { MailService } from '../mail/mail.service';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';

export class CreateReleaseDto {
  title: string;
  type?: string;
  releaseDate?: string;
  genre?: string;
  subgenre?: string;
  language?: string;
  labelName?: string;
  territories?: string[];
  distributionPlatforms?: string[];
  artworkUrl?: string;
  artworkS3Key?: string;
  submissionNotes?: string;
  upc?: string;
}

export class CreateSongDto {
  title: string;
  artistName: string;
  featuredArtists?: string[];
  composer?: string;
  producer?: string;
  lyricist?: string;
  genre?: string;
  language?: string;
  isrc?: string;
  trackNumber?: number;
  isExplicit?: boolean;
  bpm?: number;
  audioUrl?: string;
  audioS3Key?: string;
  audioFormat?: string;
  audioSizeBytes?: number;
}

@Injectable()
export class ReleasesService {
  private readonly logger = new Logger(ReleasesService.name);

  constructor(
    @InjectRepository(Release)
    private readonly releaseRepo: Repository<Release>,
    @InjectRepository(Song)
    private readonly songRepo: Repository<Song>,
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    private readonly mailService: MailService,
    @InjectQueue('release-processing') private releaseQueue: Queue,
  ) {}

  async create(userId: string, dto: CreateReleaseDto): Promise<Release> {
    const release = this.releaseRepo.create({
      ...dto,
      userId,
      status: ReleaseStatus.DRAFT,
    });
    return this.releaseRepo.save(release);
  }

  async addSong(userId: string, releaseId: string, dto: CreateSongDto): Promise<Song> {
    const release = await this.releaseRepo.findOne({ where: { id: releaseId, userId } });
    if (!release) throw new NotFoundException('Release not found');
    if (release.status !== ReleaseStatus.DRAFT) {
      throw new BadRequestException('Cannot add songs to a submitted release');
    }

    const song = this.songRepo.create({ ...dto, releaseId, userId });
    return this.songRepo.save(song);
  }

  async submit(userId: string, releaseId: string): Promise<Release> {
    const release = await this.releaseRepo.findOne({
      where: { id: releaseId, userId },
      relations: ['songs'],
    });
    if (!release) throw new NotFoundException('Release not found');
    if (release.status !== ReleaseStatus.DRAFT) {
      throw new BadRequestException('Only draft releases can be submitted');
    }
    if (!release.songs || release.songs.length === 0) {
      throw new BadRequestException('Release must have at least one song');
    }
    if (!release.artworkUrl && !release.artworkS3Key) {
      throw new BadRequestException('Release must have artwork');
    }

    release.status = ReleaseStatus.PENDING;
    release.submittedAt = new Date();
    const saved = await this.releaseRepo.save(release);

    // Queue for processing
    await this.releaseQueue.add('submitted', { releaseId, userId });

    return saved;
  }

  async findAll(userId: string, query: any = {}): Promise<{ data: Release[]; total: number }> {
    const page = parseInt(query.page) || 1;
    const limit = parseInt(query.limit) || 20;
    const skip = (page - 1) * limit;

    const where: any = { userId };
    if (query.status) where.status = query.status;

    const [data, total] = await this.releaseRepo.findAndCount({
      where,
      relations: ['songs'],
      order: { createdAt: 'DESC' },
      take: limit,
      skip,
    });

    return { data, total };
  }

  async findOne(userId: string, releaseId: string, isAdmin = false): Promise<Release> {
    const where: any = { id: releaseId };
    if (!isAdmin) where.userId = userId;

    const release = await this.releaseRepo.findOne({ where, relations: ['songs', 'user'] });
    if (!release) throw new NotFoundException('Release not found');
    return release;
  }

  async update(userId: string, releaseId: string, dto: Partial<CreateReleaseDto>): Promise<Release> {
    const release = await this.releaseRepo.findOne({ where: { id: releaseId, userId } });
    if (!release) throw new NotFoundException('Release not found');
    if (release.status !== ReleaseStatus.DRAFT) {
      throw new BadRequestException('Only draft releases can be edited');
    }
    Object.assign(release, dto);
    return this.releaseRepo.save(release);
  }

  async delete(userId: string, releaseId: string): Promise<void> {
    const release = await this.releaseRepo.findOne({ where: { id: releaseId, userId } });
    if (!release) throw new NotFoundException('Release not found');
    if ([ReleaseStatus.APPROVED, ReleaseStatus.DISTRIBUTED].includes(release.status)) {
      throw new ForbiddenException('Cannot delete an approved or distributed release');
    }
    await this.releaseRepo.remove(release);
  }

  // Admin actions
  async approve(adminId: string, releaseId: string, notes?: string): Promise<Release> {
    const release = await this.releaseRepo.findOne({
      where: { id: releaseId },
      relations: ['user'],
    });
    if (!release) throw new NotFoundException('Release not found');

    release.status = ReleaseStatus.APPROVED;
    release.reviewedAt = new Date();
    release.reviewedBy = adminId;
    if (notes) release.adminNotes = notes;
    const saved = await this.releaseRepo.save(release);

    // Notify user
    if (release.user?.email) {
      await this.mailService.sendReleaseStatusEmail(
        release.user.email,
        release.user.firstName,
        release.title,
        'approved',
      );
    }

    // Queue for distribution
    await this.releaseQueue.add('approved', { releaseId });

    return saved;
  }

  async reject(adminId: string, releaseId: string, reason: string): Promise<Release> {
    const release = await this.releaseRepo.findOne({
      where: { id: releaseId },
      relations: ['user'],
    });
    if (!release) throw new NotFoundException('Release not found');

    release.status = ReleaseStatus.REJECTED;
    release.reviewedAt = new Date();
    release.reviewedBy = adminId;
    release.rejectedReason = reason;
    const saved = await this.releaseRepo.save(release);

    if (release.user?.email) {
      await this.mailService.sendReleaseStatusEmail(
        release.user.email,
        release.user.firstName,
        release.title,
        'rejected',
        reason,
      );
    }

    return saved;
  }

  async getStats(userId?: string) {
    const where = userId ? { userId } : {};
    const total = await this.releaseRepo.count({ where });
    const pending = await this.releaseRepo.count({ where: { ...where, status: ReleaseStatus.PENDING } });
    const approved = await this.releaseRepo.count({ where: { ...where, status: ReleaseStatus.APPROVED } });
    const rejected = await this.releaseRepo.count({ where: { ...where, status: ReleaseStatus.REJECTED } });
    const distributed = await this.releaseRepo.count({ where: { ...where, status: ReleaseStatus.DISTRIBUTED } });
    return { total, pending, approved, rejected, distributed };
  }
}
