import {
  Controller, Get, Post, Put, Patch, Delete,
  Body, Param, Query, UseGuards, Request, HttpCode, HttpStatus
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { JwtAuthGuard } from '../common/guards/jwt-auth.guard';
import { AdminGuard } from '../common/guards/admin.guard';
import { ReleasesService, CreateReleaseDto, CreateSongDto } from './releases.service';

class ApproveDto { notes?: string; }
class RejectDto { reason: string; }

@ApiTags('releases')
@Controller('releases')
@UseGuards(JwtAuthGuard)
@ApiBearerAuth()
export class ReleasesController {
  constructor(private readonly releasesService: ReleasesService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new release (draft)' })
  create(@Body() dto: CreateReleaseDto, @Request() req: any) {
    return this.releasesService.create(req.user.sub, dto);
  }

  @Get()
  @ApiOperation({ summary: 'List my releases' })
  findAll(@Request() req: any, @Query() query: any) {
    return this.releasesService.findAll(req.user.sub, query);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get release statistics' })
  getStats(@Request() req: any) {
    return this.releasesService.getStats(req.user.sub);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a specific release' })
  findOne(@Param('id') id: string, @Request() req: any) {
    return this.releasesService.findOne(req.user.sub, id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a draft release' })
  update(@Param('id') id: string, @Body() dto: Partial<CreateReleaseDto>, @Request() req: any) {
    return this.releasesService.update(req.user.sub, id, dto);
  }

  @Post(':id/songs')
  @ApiOperation({ summary: 'Add a song to a release' })
  addSong(@Param('id') id: string, @Body() dto: CreateSongDto, @Request() req: any) {
    return this.releasesService.addSong(req.user.sub, id, dto);
  }

  @Post(':id/submit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Submit release for review' })
  submit(@Param('id') id: string, @Request() req: any) {
    return this.releasesService.submit(req.user.sub, id);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a draft release' })
  delete(@Param('id') id: string, @Request() req: any) {
    return this.releasesService.delete(req.user.sub, id);
  }

  // Admin actions
  @Post(':id/approve')
  @UseGuards(AdminGuard)
  @ApiOperation({ summary: '[Admin] Approve a release' })
  approve(@Param('id') id: string, @Body() dto: ApproveDto, @Request() req: any) {
    return this.releasesService.approve(req.user.sub, id, dto.notes);
  }

  @Post(':id/reject')
  @UseGuards(AdminGuard)
  @ApiOperation({ summary: '[Admin] Reject a release' })
  reject(@Param('id') id: string, @Body() dto: RejectDto, @Request() req: any) {
    return this.releasesService.reject(req.user.sub, id, dto.reason);
  }
}
