import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany, JoinColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Song } from './song.entity';

export enum ReleaseType {
  SINGLE = 'single',
  EP = 'ep',
  ALBUM = 'album',
  COMPILATION = 'compilation',
}

export enum ReleaseStatus {
  DRAFT = 'draft',
  PENDING = 'pending',
  PROCESSING = 'processing',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  DISTRIBUTED = 'distributed',
  TAKEDOWN = 'takedown',
}

@Entity('releases')
export class Release {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'user_id' })
  userId: string;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column()
  title: string;

  @Column({ type: 'enum', enum: ReleaseType, default: ReleaseType.SINGLE })
  type: ReleaseType;

  @Column({ type: 'enum', enum: ReleaseStatus, default: ReleaseStatus.DRAFT })
  status: ReleaseStatus;

  @Column({ name: 'release_date', nullable: true, type: 'date' })
  releaseDate: Date;

  @Column({ name: 'artwork_url', nullable: true })
  artworkUrl: string;

  @Column({ name: 'artwork_s3_key', nullable: true })
  artworkS3Key: string;

  @Column({ name: 'label_name', nullable: true })
  labelName: string;

  @Column({ nullable: true })
  upc: string;

  @Column({ nullable: true })
  genre: string;

  @Column({ nullable: true })
  subgenre: string;

  @Column({ nullable: true })
  language: string;

  @Column({ type: 'text', array: true, default: ['worldwide'] })
  territories: string[];

  @Column({ name: 'distribution_platforms', type: 'text', array: true, default: [] })
  distributionPlatforms: string[];

  @Column({ name: 'submission_notes', nullable: true })
  submissionNotes: string;

  @Column({ name: 'admin_notes', nullable: true })
  adminNotes: string;

  @Column({ name: 'rejected_reason', nullable: true })
  rejectedReason: string;

  @Column({ name: 'submitted_at', nullable: true })
  submittedAt: Date;

  @Column({ name: 'reviewed_at', nullable: true })
  reviewedAt: Date;

  @Column({ name: 'reviewed_by', nullable: true })
  reviewedBy: string;

  @Column({ type: 'jsonb', default: {} })
  metadata: Record<string, any>;

  @OneToMany(() => Song, (song) => song.release, { cascade: true })
  songs: Song[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
