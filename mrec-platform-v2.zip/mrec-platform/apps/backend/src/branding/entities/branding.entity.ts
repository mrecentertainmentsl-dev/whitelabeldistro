import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('branding')
export class Branding {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ name: 'platform_name', default: 'MREC Entertainment' })
  platformName: string;

  @Column({ nullable: true })
  tagline: string;

  @Column({ name: 'logo_url', nullable: true })
  logoUrl: string;

  @Column({ name: 'logo_s3_key', nullable: true })
  logoS3Key: string;

  @Column({ name: 'favicon_url', nullable: true })
  faviconUrl: string;

  @Column({ name: 'favicon_s3_key', nullable: true })
  faviconS3Key: string;

  @Column({ name: 'primary_color', default: '#7C3AED' })
  primaryColor: string;

  @Column({ name: 'secondary_color', default: '#A855F7' })
  secondaryColor: string;

  @Column({ name: 'accent_color', default: '#F59E0B' })
  accentColor: string;

  @Column({ name: 'background_color', default: '#0F0F0F' })
  backgroundColor: string;

  @Column({ name: 'text_color', default: '#FFFFFF' })
  textColor: string;

  @Column({ name: 'font_heading', default: 'Inter' })
  fontHeading: string;

  @Column({ name: 'font_body', default: 'Inter' })
  fontBody: string;

  @Column({ name: 'custom_css', nullable: true, type: 'text' })
  customCss: string;

  @Column({ name: 'footer_text', nullable: true })
  footerText: string;

  @Column({ name: 'support_email', nullable: true })
  supportEmail: string;

  @Column({ name: 'support_url', nullable: true })
  supportUrl: string;

  @Column({ name: 'terms_url', nullable: true })
  termsUrl: string;

  @Column({ name: 'privacy_url', nullable: true })
  privacyUrl: string;

  @Column({ type: 'jsonb', default: {} })
  socialLinks: Record<string, string>;

  @Column({ name: 'is_active', default: true })
  isActive: boolean;

  @Column({ name: 'domain_id', nullable: true })
  domainId: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
