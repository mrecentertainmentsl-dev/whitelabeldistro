'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { api } from './api';

interface Branding {
  platformName: string;
  tagline?: string;
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  fontHeading: string;
  fontBody: string;
  customCss?: string;
  supportEmail?: string;
}

const defaultBranding: Branding = {
  platformName: 'MREC Entertainment',
  primaryColor: '#7C3AED',
  secondaryColor: '#A855F7',
  accentColor: '#F59E0B',
  backgroundColor: '#0A0A0F',
  textColor: '#FFFFFF',
  fontHeading: 'Syne',
  fontBody: 'DM Sans',
};

const BrandingContext = createContext<Branding>(defaultBranding);

export function BrandingProvider({ children }: { children: React.ReactNode }) {
  const [branding, setBranding] = useState<Branding>(defaultBranding);

  useEffect(() => {
    api.get('/branding/public')
      .then(res => {
        const b = res.data;
        setBranding({ ...defaultBranding, ...b });
        applyBrandingToDOM(b);
      })
      .catch(() => applyBrandingToDOM(defaultBranding));
  }, []);

  return (
    <BrandingContext.Provider value={branding}>
      {children}
    </BrandingContext.Provider>
  );
}

export const useBranding = () => useContext(BrandingContext);

function applyBrandingToDOM(b: Partial<Branding>) {
  const root = document.documentElement;
  if (b.primaryColor) root.style.setProperty('--color-primary', b.primaryColor);
  if (b.secondaryColor) root.style.setProperty('--color-secondary', b.secondaryColor);
  if (b.accentColor) root.style.setProperty('--color-accent', b.accentColor);
  if (b.backgroundColor) root.style.setProperty('--color-background', b.backgroundColor);
  if (b.textColor) root.style.setProperty('--color-text', b.textColor);

  // Custom CSS injection
  if (b.customCss) {
    const existing = document.getElementById('custom-branding-css');
    if (existing) existing.remove();
    const style = document.createElement('style');
    style.id = 'custom-branding-css';
    style.textContent = b.customCss;
    document.head.appendChild(style);
  }

  // Favicon
  if (b.faviconUrl) {
    const link = document.querySelector<HTMLLinkElement>("link[rel='icon']");
    if (link) link.href = b.faviconUrl;
  }

  // Page title
  if (b.platformName) {
    document.title = b.platformName;
  }
}
