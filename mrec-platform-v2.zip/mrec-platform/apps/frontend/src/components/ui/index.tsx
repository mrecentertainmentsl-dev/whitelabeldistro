'use client';

import { Loader2, Inbox } from 'lucide-react';
import Link from 'next/link';

// ─── StatusBadge ─────────────────────────────────────────────────────────────
const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  draft:       { label: 'Draft',        cls: 'status-draft' },
  pending:     { label: 'Pending',      cls: 'status-pending' },
  processing:  { label: 'Processing',   cls: 'status-pending' },
  approved:    { label: 'Approved',     cls: 'status-approved' },
  rejected:    { label: 'Rejected',     cls: 'status-rejected' },
  distributed: { label: 'Distributed',  cls: 'status-distributed' },
  takedown:    { label: 'Takedown',     cls: 'status-rejected' },
  active:      { label: 'Active',       cls: 'status-approved' },
  suspended:   { label: 'Suspended',    cls: 'status-rejected' },
};

export function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_MAP[status] || { label: status, cls: 'status-draft' };
  return <span className={cfg.cls}>{cfg.label}</span>;
}

// ─── Spinner ─────────────────────────────────────────────────────────────────
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-6 h-6', lg: 'w-8 h-8' };
  return <Loader2 className={`${sizes[size]} animate-spin text-gray-400`} />;
}

export function PageLoader() {
  return (
    <div className="flex items-center justify-center py-20">
      <Spinner size="lg" />
    </div>
  );
}

// ─── EmptyState ───────────────────────────────────────────────────────────────
interface EmptyStateProps {
  icon?: any;
  title: string;
  description?: string;
  actionLabel?: string;
  actionHref?: string;
  onAction?: () => void;
}

export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  actionLabel,
  actionHref,
  onAction,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 bg-[var(--color-surface-elevated)]">
        <Icon className="w-7 h-7 text-gray-500" />
      </div>
      <h3 className="font-heading font-semibold text-white mb-1">{title}</h3>
      {description && <p className="text-gray-400 text-sm max-w-sm mt-1 leading-relaxed">{description}</p>}
      {actionLabel && actionHref && (
        <Link href={actionHref} className="btn-primary mt-5 text-sm">{actionLabel}</Link>
      )}
      {actionLabel && onAction && (
        <button onClick={onAction} className="btn-primary mt-5 text-sm">{actionLabel}</button>
      )}
    </div>
  );
}

// ─── Pagination ───────────────────────────────────────────────────────────────
interface PaginationProps {
  page: number;
  total: number;
  pageSize?: number;
  onChange: (page: number) => void;
}

export function Pagination({ page, total, pageSize = 20, onChange }: PaginationProps) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-gray-400">
        Showing {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, total)} of {total}
      </span>
      <div className="flex items-center gap-1">
        <button
          disabled={page === 1}
          onClick={() => onChange(page - 1)}
          className="px-3 py-1.5 rounded-lg border border-[var(--color-surface-border)] text-gray-400 hover:text-white hover:border-[var(--color-primary)] transition-all disabled:opacity-30 disabled:cursor-not-allowed text-xs">
          Previous
        </button>
        {[...Array(Math.min(totalPages, 5))].map((_, i) => {
          const p = i + 1;
          return (
            <button
              key={p}
              onClick={() => onChange(p)}
              className={`w-8 h-8 rounded-lg text-xs font-medium transition-all ${
                page === p
                  ? 'text-white border-transparent'
                  : 'text-gray-400 border border-[var(--color-surface-border)] hover:text-white'
              }`}
              style={page === p ? { background: 'var(--gradient-brand)' } : {}}>
              {p}
            </button>
          );
        })}
        <button
          disabled={page >= totalPages}
          onClick={() => onChange(page + 1)}
          className="px-3 py-1.5 rounded-lg border border-[var(--color-surface-border)] text-gray-400 hover:text-white hover:border-[var(--color-primary)] transition-all disabled:opacity-30 disabled:cursor-not-allowed text-xs">
          Next
        </button>
      </div>
    </div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
export function Card({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`card ${className}`}>{children}</div>;
}

// ─── Section Header ───────────────────────────────────────────────────────────
export function SectionHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">{title}</h1>
        {description && <p className="text-gray-400 mt-1 text-sm">{description}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
export function StatCard({
  label,
  value,
  icon: Icon,
  color,
  sub,
  trend,
}: {
  label: string;
  value: number | string;
  icon: any;
  color: string;
  sub?: string;
  trend?: { value: number; label: string };
}) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-gray-400">{label}</span>
        <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${color}20` }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
      </div>
      <p className="text-3xl font-heading font-bold text-white">{value ?? 0}</p>
      {sub && <p className="text-xs text-gray-500 mt-1">{sub}</p>}
      {trend && (
        <div className={`flex items-center gap-1 mt-2 text-xs ${trend.value >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
          <span>{trend.value >= 0 ? '↑' : '↓'} {Math.abs(trend.value)}%</span>
          <span className="text-gray-500">{trend.label}</span>
        </div>
      )}
    </div>
  );
}
