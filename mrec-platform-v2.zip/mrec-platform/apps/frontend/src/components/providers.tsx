'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';
import { BrandingProvider } from '@/lib/branding-context';

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () => new QueryClient({
      defaultOptions: {
        queries: { staleTime: 60 * 1000, retry: 1 },
      },
    }),
  );

  return (
    <QueryClientProvider client={queryClient}>
      <BrandingProvider>
        {children}
      </BrandingProvider>
    </QueryClientProvider>
  );
}
