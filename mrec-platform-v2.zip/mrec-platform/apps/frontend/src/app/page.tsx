import Link from 'next/link';
import { Music2, Globe, Shield, Zap, CheckCircle, ArrowRight, Headphones } from 'lucide-react';

const platforms = ['Spotify', 'Apple Music', 'YouTube Music', 'TikTok', 'Deezer', 'Amazon Music'];
const features = [
  { icon: Globe, title: 'Global Distribution', desc: 'Reach 150+ streaming platforms and stores worldwide with one upload.' },
  { icon: Shield, title: 'Keep 100% Rights', desc: 'You own your music. We just distribute it. No hidden fees or rights grabs.' },
  { icon: Zap, title: 'Fast Approval', desc: 'Our team reviews and approves releases within 24-48 hours.' },
  { icon: Music2, title: 'Studio Quality', desc: 'Upload WAV and FLAC files — we never compress your music.' },
];

export default function HomePage() {
  return (
    <div className="min-h-screen" style={{ background: 'var(--color-background)' }}>
      {/* Nav */}
      <nav className="fixed top-0 w-full z-50 border-b border-[var(--color-surface-border)] backdrop-blur-xl bg-black/40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--gradient-brand)' }}>
              <Headphones className="w-4 h-4 text-white" />
            </div>
            <span className="font-heading font-bold text-lg text-white">MREC Entertainment</span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login" className="btn-secondary text-sm">Sign In</Link>
            <Link href="/auth/register" className="btn-primary text-sm">Get Started</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-40 pb-24 px-6 text-center relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-[800px] h-[500px] rounded-full opacity-20 blur-[120px]"
               style={{ background: 'radial-gradient(ellipse, var(--color-primary), transparent 70%)' }} />
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[var(--color-surface-border)] bg-[var(--color-surface)] text-sm text-gray-400 mb-8">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Now distributing to 150+ platforms
          </div>

          <h1 className="font-heading text-5xl md:text-7xl font-extrabold text-white leading-[1.05] mb-6">
            Distribute Your Music{' '}
            <span style={{ background: 'var(--gradient-brand)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Globally
            </span>
          </h1>

          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Upload once. Reach millions. Keep everything you earn.
            Professional music distribution built for independent artists and labels.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/auth/register" className="btn-primary flex items-center gap-2 text-base px-8 py-3">
              Start Distributing <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/auth/login" className="btn-secondary text-base px-8 py-3">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Platform logos */}
      <section className="py-12 border-y border-[var(--color-surface-border)] bg-[var(--color-surface)]/30">
        <div className="max-w-5xl mx-auto px-6">
          <p className="text-center text-sm text-gray-500 mb-8 uppercase tracking-widest">Distribute to all major platforms</p>
          <div className="flex flex-wrap items-center justify-center gap-8">
            {platforms.map((p) => (
              <span key={p} className="text-gray-400 font-heading font-semibold text-lg hover:text-white transition-colors">{p}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="font-heading text-4xl font-bold text-white mb-4">Everything you need to distribute</h2>
            <p className="text-gray-400 text-lg max-w-xl mx-auto">
              Professional tools built for independent artists who mean business.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="card p-6 hover:border-[var(--color-primary)]/40 transition-all duration-300 group">
                <div className="w-11 h-11 rounded-xl mb-5 flex items-center justify-center"
                     style={{ background: 'rgba(124, 58, 237, 0.15)' }}>
                  <Icon className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
                </div>
                <h3 className="font-heading font-semibold text-white mb-2">{title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6">
        <div className="max-w-2xl mx-auto text-center card p-12">
          <h2 className="font-heading text-3xl font-bold text-white mb-4">Ready to go global?</h2>
          <p className="text-gray-400 mb-8">Join thousands of artists already distributing with us.</p>
          <Link href="/auth/register" className="btn-primary inline-flex items-center gap-2 text-base px-10 py-3">
            Create Free Account <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[var(--color-surface-border)] py-10 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded flex items-center justify-center" style={{ background: 'var(--gradient-brand)' }}>
              <Headphones className="w-3 h-3 text-white" />
            </div>
            <span className="text-sm text-gray-400">© 2025 MREC Entertainment</span>
          </div>
          <div className="flex gap-6 text-sm text-gray-500">
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
