'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft, Music2, CheckCircle, XCircle, User,
  Calendar, Tag, Globe2, Clock, Loader2, Edit2, Save
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function AdminReleaseDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const qc = useQueryClient();
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [adminNotes, setAdminNotes] = useState('');
  const [editingMeta, setEditingMeta] = useState(false);
  const [metaForm, setMetaForm] = useState<any>({});

  const { data: release, isLoading } = useQuery({
    queryKey: ['admin-release', id],
    queryFn: () => api.get(`/api/v1/admin/releases/${id}`).then(r => r.data),
    onSuccess: (d: any) => setMetaForm({ title: d.title, genre: d.genre, language: d.language, labelName: d.labelName }),
  });

  const approveMutation = useMutation({
    mutationFn: () => api.post(`/api/v1/releases/${id}/approve`, { notes: adminNotes }),
    onSuccess: () => {
      toast.success('Release approved!');
      qc.invalidateQueries({ queryKey: ['admin-release', id] });
      qc.invalidateQueries({ queryKey: ['admin-overview'] });
    },
    onError: () => toast.error('Approval failed'),
  });

  const rejectMutation = useMutation({
    mutationFn: () => api.post(`/api/v1/releases/${id}/reject`, { reason: rejectReason }),
    onSuccess: () => {
      toast.success('Release rejected');
      setShowRejectForm(false);
      qc.invalidateQueries({ queryKey: ['admin-release', id] });
    },
    onError: () => toast.error('Rejection failed'),
  });

  const updateMetaMutation = useMutation({
    mutationFn: () => api.patch(`/api/v1/admin/releases/${id}/metadata`, metaForm),
    onSuccess: () => {
      toast.success('Metadata updated');
      setEditingMeta(false);
      qc.invalidateQueries({ queryKey: ['admin-release', id] });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 animate-spin text-gray-500" />
      </div>
    );
  }

  if (!release) return <div className="text-gray-400">Release not found.</div>;

  const isPending = release.status === 'pending';

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl">
      <div className="flex items-center justify-between">
        <Link href="/admin/releases" className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Releases
        </Link>
        {isPending && (
          <div className="flex items-center gap-2">
            <span className="status-pending">Awaiting Review</span>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left column */}
        <div className="space-y-4">
          {/* Artwork */}
          <div className="aspect-square rounded-xl overflow-hidden bg-[var(--color-surface-elevated)] flex items-center justify-center">
            {release.artworkUrl ? (
              <img src={release.artworkUrl} alt={release.title} className="w-full h-full object-cover" />
            ) : (
              <Music2 className="w-16 h-16 text-gray-600" />
            )}
          </div>

          {/* Artist info */}
          <div className="card p-4 space-y-2">
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-3">Artist</p>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white shrink-0"
                   style={{ background: 'var(--gradient-brand)' }}>
                {release.user?.firstName?.[0]}{release.user?.lastName?.[0]}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-white truncate">
                  {release.user?.firstName} {release.user?.lastName}
                </p>
                <p className="text-xs text-gray-500 truncate">{release.user?.email}</p>
              </div>
            </div>
          </div>

          {/* Metadata */}
          <div className="card p-4 space-y-3">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-gray-500 uppercase tracking-wider">Metadata</p>
              <button onClick={() => setEditingMeta(!editingMeta)}
                      className="text-xs text-gray-500 hover:text-white transition-colors flex items-center gap-1">
                <Edit2 className="w-3 h-3" /> {editingMeta ? 'Cancel' : 'Edit'}
              </button>
            </div>

            {editingMeta ? (
              <div className="space-y-3">
                {[
                  { key: 'title', label: 'Title' },
                  { key: 'genre', label: 'Genre' },
                  { key: 'language', label: 'Language' },
                  { key: 'labelName', label: 'Label' },
                ].map(({ key, label }) => (
                  <div key={key}>
                    <label className="text-xs text-gray-500">{label}</label>
                    <input
                      className="input mt-1 text-sm py-1.5"
                      value={metaForm[key] || ''}
                      onChange={e => setMetaForm((p: any) => ({ ...p, [key]: e.target.value }))}
                    />
                  </div>
                ))}
                <button
                  onClick={() => updateMetaMutation.mutate()}
                  disabled={updateMetaMutation.isPending}
                  className="btn-primary w-full text-sm flex items-center justify-center gap-2 py-2">
                  {updateMetaMutation.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  Save Changes
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {[
                  { icon: Tag, label: 'Genre', value: release.genre },
                  { icon: Globe2, label: 'Language', value: release.language },
                  { icon: Calendar, label: 'Release Date', value: release.releaseDate ? format(new Date(release.releaseDate), 'MMM d, yyyy') : null },
                  { icon: User, label: 'Label', value: release.labelName },
                  { icon: Tag, label: 'UPC', value: release.upc },
                  { icon: Clock, label: 'Submitted', value: release.submittedAt ? format(new Date(release.submittedAt), 'MMM d, yyyy HH:mm') : null },
                ].map(({ icon: Icon, label, value }) =>
                  value ? (
                    <div key={label} className="flex items-start gap-2">
                      <Icon className="w-3.5 h-3.5 text-gray-500 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs text-gray-500">{label}</p>
                        <p className="text-xs text-white">{value}</p>
                      </div>
                    </div>
                  ) : null
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right column */}
        <div className="lg:col-span-2 space-y-5">
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-1 capitalize">{release.type}</p>
            <h1 className="font-heading text-3xl font-bold text-white">{release.title}</h1>
            <p className="text-gray-400 text-sm mt-1">
              {release.songs?.length ?? 0} track{release.songs?.length !== 1 ? 's' : ''}
              {release.genre ? ` · ${release.genre}` : ''}
              {release.language ? ` · ${release.language}` : ''}
            </p>
          </div>

          {/* Submission notes */}
          {release.submissionNotes && (
            <div className="card p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Artist Notes</p>
              <p className="text-sm text-gray-300 leading-relaxed">{release.submissionNotes}</p>
            </div>
          )}

          {/* Track list */}
          <div className="card overflow-hidden">
            <div className="px-4 py-3 border-b border-[var(--color-surface-border)]">
              <h3 className="font-heading font-semibold text-white text-sm">Tracks</h3>
            </div>
            <div className="divide-y divide-[var(--color-surface-border)]">
              {(release.songs || []).map((s: any, i: number) => (
                <div key={s.id} className="flex items-center gap-4 px-4 py-3">
                  <span className="text-gray-600 text-sm w-5 text-right shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{s.title}</p>
                    <p className="text-xs text-gray-500">
                      {s.artistName}
                      {s.featuredArtists?.length > 0 && ` feat. ${s.featuredArtists.join(', ')}`}
                      {s.composer && ` · Composed by ${s.composer}`}
                      {s.producer && ` · Produced by ${s.producer}`}
                    </p>
                  </div>
                  <div className="text-right shrink-0 space-y-0.5">
                    {s.isExplicit && <span className="px-1.5 py-0.5 rounded text-xs bg-red-500/20 text-red-400">E</span>}
                    {s.isrc && <p className="text-xs text-gray-600 font-mono">{s.isrc}</p>}
                    {s.audioFormat && <p className="text-xs text-gray-600 uppercase">{s.audioFormat}</p>}
                  </div>
                  {s.audioUrl && (
                    <a href={s.audioUrl} target="_blank" rel="noopener noreferrer"
                       className="text-xs text-purple-400 hover:text-purple-300 transition-colors shrink-0">
                      Preview
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Approve / Reject actions */}
          {isPending && (
            <div className="card p-5 space-y-4">
              <h3 className="font-heading font-semibold text-white">Review Decision</h3>

              <div>
                <label className="label">Admin Notes <span className="text-gray-500">(optional, shown to artist if approved)</span></label>
                <textarea
                  value={adminNotes}
                  onChange={e => setAdminNotes(e.target.value)}
                  className="input h-20 resize-none text-sm"
                  placeholder="Any notes for the artist..."
                />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => approveMutation.mutate()}
                  disabled={approveMutation.isPending}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all font-semibold text-sm">
                  {approveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                  Approve & Queue Distribution
                </button>
                <button
                  onClick={() => setShowRejectForm(!showRejectForm)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25 transition-all font-semibold text-sm">
                  <XCircle className="w-4 h-4" />
                  Reject
                </button>
              </div>

              {showRejectForm && (
                <div className="space-y-3 pt-2 border-t border-[var(--color-surface-border)]">
                  <div>
                    <label className="label">Rejection Reason * <span className="text-gray-500">(sent to artist)</span></label>
                    <textarea
                      value={rejectReason}
                      onChange={e => setRejectReason(e.target.value)}
                      className="input h-24 resize-none text-sm"
                      placeholder="Explain clearly what needs to be fixed so the artist can resubmit..."
                    />
                  </div>
                  <button
                    onClick={() => { if (!rejectReason.trim()) { toast.error('Please provide a reason'); return; } rejectMutation.mutate(); }}
                    disabled={rejectMutation.isPending}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-all font-semibold text-sm">
                    {rejectMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                    Confirm Rejection
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Already reviewed */}
          {!isPending && (
            <div className={`card p-4 ${release.status === 'approved' || release.status === 'distributed' ? 'border-emerald-500/20' : release.status === 'rejected' ? 'border-red-500/20' : ''}`}>
              <p className="text-sm font-medium text-white mb-1 capitalize">Status: {release.status}</p>
              {release.reviewedAt && (
                <p className="text-xs text-gray-500">Reviewed {format(new Date(release.reviewedAt), 'MMM d, yyyy HH:mm')}</p>
              )}
              {release.adminNotes && (
                <p className="text-xs text-gray-400 mt-2">{release.adminNotes}</p>
              )}
              {release.rejectedReason && (
                <div className="mt-2 p-3 rounded-lg bg-red-500/10">
                  <p className="text-xs text-red-400">{release.rejectedReason}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
