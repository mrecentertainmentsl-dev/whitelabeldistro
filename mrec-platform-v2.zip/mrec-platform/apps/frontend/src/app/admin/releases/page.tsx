'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { Search, Music2, ExternalLink, Loader2 } from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

const STATUS_CONFIG: Record<string, { label: string; cls: string }> = {
  draft:       { label: 'Draft',       cls: 'status-draft' },
  pending:     { label: 'Pending',     cls: 'status-pending' },
  approved:    { label: 'Approved',    cls: 'status-approved' },
  rejected:    { label: 'Rejected',    cls: 'status-rejected' },
  distributed: { label: 'Distributed', cls: 'status-distributed' },
  processing:  { label: 'Processing',  cls: 'status-pending' },
};

const STATUS_OPTIONS = ['all', 'pending', 'draft', 'approved', 'rejected', 'distributed'];

export default function AdminReleasesPage() {
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['admin-releases', status, page, search],
    queryFn: () =>
      api.get(`/api/v1/admin/releases?page=${page}&limit=20${status !== 'all' ? `&status=${status}` : ''}${search ? `&search=${search}` : ''}`).then(r => r.data),
  });

  const releases = data?.data || [];
  const total = data?.total || 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">All Releases</h1>
        <p className="text-gray-400 mt-1">{total} total releases on the platform</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input className="input pl-9" placeholder="Search by title or artist email…"
                 value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} />
        </div>
        <div className="flex gap-1.5">
          {STATUS_OPTIONS.map(s => (
            <button key={s} onClick={() => { setStatus(s); setPage(1); }}
                    className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all border ${
                      status === s
                        ? 'text-white border-transparent'
                        : 'text-gray-400 border-[var(--color-surface-border)] hover:text-white bg-[var(--color-surface)]'
                    }`}
                    style={status === s ? { background: 'var(--gradient-brand)' } : {}}>
              {s === 'all' ? 'All' : STATUS_CONFIG[s]?.label || s}
            </button>
          ))}
        </div>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--color-surface-border)]">
              {['Release', 'Artist', 'Type', 'Status', 'Submitted', 'Actions'].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--color-surface-border)]">
            {isLoading ? (
              <tr><td colSpan={6} className="px-4 py-12 text-center">
                <Loader2 className="w-5 h-5 animate-spin text-gray-500 mx-auto" />
              </td></tr>
            ) : releases.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-12 text-center text-gray-500">No releases found</td></tr>
            ) : releases.map((r: any) => {
              const st = STATUS_CONFIG[r.status] || STATUS_CONFIG.draft;
              return (
                <tr key={r.id} className="hover:bg-[var(--color-surface-elevated)] transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {r.artworkUrl ? (
                        <img src={r.artworkUrl} alt={r.title} className="w-9 h-9 rounded object-cover shrink-0" />
                      ) : (
                        <div className="w-9 h-9 rounded flex items-center justify-center shrink-0 bg-[var(--color-surface-elevated)]">
                          <Music2 className="w-4 h-4 text-gray-500" />
                        </div>
                      )}
                      <div>
                        <p className="font-medium text-white truncate max-w-[180px]">{r.title}</p>
                        <p className="text-xs text-gray-500">{r.songs?.length ?? 0} tracks</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-400 text-xs truncate max-w-[150px]">{r.user?.email || '—'}</td>
                  <td className="px-4 py-3 text-gray-400 capitalize text-xs">{r.type}</td>
                  <td className="px-4 py-3"><span className={st.cls}>{st.label}</span></td>
                  <td className="px-4 py-3 text-gray-500 text-xs">
                    {r.submittedAt ? format(new Date(r.submittedAt), 'MMM d, yyyy') : '—'}
                  </td>
                  <td className="px-4 py-3">
                    <Link href={`/admin/releases/${r.id}`}
                          className="flex items-center gap-1 text-xs text-gray-500 hover:text-[var(--color-primary)] transition-colors">
                      <ExternalLink className="w-3.5 h-3.5" /> View
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {total > 20 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--color-surface-border)]">
            <span className="text-sm text-gray-400">
              Showing {(page - 1) * 20 + 1}–{Math.min(page * 20, total)} of {total}
            </span>
            <div className="flex gap-2">
              <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-40">Prev</button>
              <button disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)} className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-40">Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
