'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileText, Loader2, RefreshCw } from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

const ACTION_COLORS: Record<string, string> = {
  approve: 'text-emerald-400',
  reject: 'text-red-400',
  delete: 'text-red-400',
  toggle: 'text-amber-400',
  edit: 'text-blue-400',
  create: 'text-purple-400',
};

function getActionColor(action: string): string {
  for (const [key, color] of Object.entries(ACTION_COLORS)) {
    if (action.toLowerCase().includes(key)) return color;
  }
  return 'text-gray-300';
}

export default function AdminLogsPage() {
  const [page, setPage] = useState(1);

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['admin-logs', page],
    queryFn: () => api.get(`/api/v1/admin/logs?page=${page}&limit=50`).then(r => r.data),
    refetchInterval: 30000,
  });

  const logs = data?.data || [];
  const total = data?.total || 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">System Logs</h1>
          <p className="text-gray-400 mt-1">Audit trail of all admin actions</p>
        </div>
        <button onClick={() => refetch()} disabled={isFetching}
                className="btn-secondary flex items-center gap-2 text-sm">
          <RefreshCw className={`w-4 h-4 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      <div className="card overflow-hidden">
        {isLoading ? (
          <div className="py-16 flex items-center justify-center">
            <Loader2 className="w-6 h-6 animate-spin text-gray-500" />
          </div>
        ) : logs.length === 0 ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <FileText className="w-10 h-10 text-gray-600" />
            <p className="text-gray-400">No log entries yet</p>
          </div>
        ) : (
          <>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--color-surface-border)]">
                  {['Time', 'Admin', 'Action', 'Entity', 'Details'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--color-surface-border)] font-mono">
                {logs.map((log: any) => (
                  <tr key={log.id} className="hover:bg-[var(--color-surface-elevated)] transition-colors">
                    <td className="px-4 py-2.5 text-xs text-gray-500 whitespace-nowrap">
                      {format(new Date(log.createdAt), 'MMM d HH:mm:ss')}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-gray-400 whitespace-nowrap">
                      {log.admin?.email ? log.admin.email.split('@')[0] : 'system'}
                    </td>
                    <td className={`px-4 py-2.5 text-xs font-medium whitespace-nowrap ${getActionColor(log.action)}`}>
                      {log.action}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-gray-500">
                      {log.entityType && (
                        <span className="capitalize">{log.entityType}</span>
                      )}
                      {log.entityId && (
                        <span className="text-gray-700 ml-1 text-[10px]">{log.entityId.slice(0, 8)}…</span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-xs text-gray-600 max-w-[200px] truncate">
                      {log.message || (log.newValue ? JSON.stringify(log.newValue).slice(0, 60) : '—')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {total > 50 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--color-surface-border)]">
                <span className="text-sm text-gray-400">{total} total entries</span>
                <div className="flex gap-2">
                  <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-40">Prev</button>
                  <button disabled={page * 50 >= total} onClick={() => setPage(p => p + 1)} className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-40">Next</button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
