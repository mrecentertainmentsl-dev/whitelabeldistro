'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-hot-toast';
import { CheckCircle, XCircle, Music2, Clock, ExternalLink, Loader2 } from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

export default function ApprovalsPage() {
  const queryClient = useQueryClient();
  const [rejectId, setRejectId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['pending-releases'],
    queryFn: () => api.get('/api/v1/admin/releases?status=pending&limit=50').then(r => r.data),
    refetchInterval: 15000,
  });

  const approveMutation = useMutation({
    mutationFn: ({ id, notes }: { id: string; notes?: string }) =>
      api.post(`/api/v1/releases/${id}/approve`, { notes }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-releases'] });
      queryClient.invalidateQueries({ queryKey: ['admin-overview'] });
      toast.success('Release approved and queued for distribution 🎉');
      setProcessingId(null);
    },
    onError: () => { toast.error('Approval failed'); setProcessingId(null); },
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      api.post(`/api/v1/releases/${id}/reject`, { reason }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pending-releases'] });
      queryClient.invalidateQueries({ queryKey: ['admin-overview'] });
      toast.success('Release rejected');
      setRejectId(null);
      setRejectReason('');
      setProcessingId(null);
    },
    onError: () => { toast.error('Rejection failed'); setProcessingId(null); },
  });

  const handleApprove = (id: string) => {
    setProcessingId(id);
    approveMutation.mutate({ id });
  };

  const handleReject = () => {
    if (!rejectId || !rejectReason.trim()) { toast.error('Please provide a reason'); return; }
    setProcessingId(rejectId);
    rejectMutation.mutate({ id: rejectId, reason: rejectReason });
  };

  const releases = data?.data || [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">Approval Queue</h1>
          <p className="text-gray-400 mt-1">
            {releases.length} pending release{releases.length !== 1 ? 's' : ''} awaiting review
          </p>
        </div>
        {releases.length > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/20">
            <Clock className="w-4 h-4 text-amber-400" />
            <span className="text-amber-400 text-sm font-medium">{releases.length} pending</span>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="card p-12 flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-gray-500" />
        </div>
      ) : releases.length === 0 ? (
        <div className="card p-16 text-center">
          <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
          <h3 className="font-heading text-lg font-semibold text-white mb-2">All caught up!</h3>
          <p className="text-gray-400">No pending releases to review right now.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {releases.map((r: any) => (
            <div key={r.id} className="card p-5">
              <div className="flex items-start gap-4">
                {r.artworkUrl ? (
                  <img src={r.artworkUrl} alt={r.title} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                ) : (
                  <div className="w-16 h-16 rounded-xl flex items-center justify-center shrink-0 bg-[var(--color-surface-elevated)]">
                    <Music2 className="w-6 h-6 text-gray-500" />
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-heading font-semibold text-white text-lg">{r.title}</h3>
                      <p className="text-gray-400 text-sm mt-0.5">
                        by <span className="text-white">{r.user?.email}</span>
                      </p>
                    </div>
                    <span className="status-pending shrink-0">Pending Review</span>
                  </div>

                  <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-400">
                    <span className="capitalize">{r.type}</span>
                    {r.genre && <span className="capitalize">{r.genre}</span>}
                    {r.language && <span className="capitalize">{r.language}</span>}
                    <span>{r.songs?.length ?? 0} track{r.songs?.length !== 1 ? 's' : ''}</span>
                    <span>Submitted {format(new Date(r.submittedAt || r.createdAt), 'MMM d, yyyy')}</span>
                  </div>

                  {r.submissionNotes && (
                    <div className="mt-3 p-3 rounded-lg bg-[var(--color-surface-elevated)] text-sm text-gray-300">
                      <span className="text-gray-500 text-xs uppercase tracking-wider">Artist note: </span>
                      {r.submissionNotes}
                    </div>
                  )}

                  {/* Tracks */}
                  {r.songs?.length > 0 && (
                    <div className="mt-3 space-y-1">
                      {r.songs.map((s: any, i: number) => (
                        <div key={s.id} className="flex items-center gap-2 text-sm text-gray-400">
                          <span className="text-gray-600 w-4 text-right shrink-0">{i + 1}</span>
                          <Music2 className="w-3.5 h-3.5 text-gray-600 shrink-0" />
                          <span className="text-white">{s.title}</span>
                          {s.isExplicit && <span className="text-xs bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded">E</span>}
                          {s.audioUrl && (
                            <a href={s.audioUrl} target="_blank" rel="noopener noreferrer"
                               className="ml-auto text-gray-600 hover:text-purple-400 transition-colors">
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3 mt-5 pt-4 border-t border-[var(--color-surface-border)]">
                <button
                  onClick={() => handleApprove(r.id)}
                  disabled={processingId === r.id}
                  className="flex items-center gap-2 px-5 py-2 rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 transition-all text-sm font-medium disabled:opacity-50">
                  {processingId === r.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                  Approve
                </button>
                <button
                  onClick={() => { setRejectId(r.id); setRejectReason(''); }}
                  disabled={processingId === r.id}
                  className="flex items-center gap-2 px-5 py-2 rounded-lg bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25 transition-all text-sm font-medium disabled:opacity-50">
                  <XCircle className="w-4 h-4" />
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Reject modal */}
      {rejectId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="card max-w-md w-full p-6 space-y-4">
            <h3 className="font-heading font-semibold text-white text-lg">Reject Release</h3>
            <p className="text-gray-400 text-sm">The artist will be notified with your reason.</p>
            <div>
              <label className="label">Rejection Reason *</label>
              <textarea
                value={rejectReason}
                onChange={e => setRejectReason(e.target.value)}
                className="input h-28 resize-none"
                placeholder="e.g. Audio quality does not meet requirements. Please re-upload as 24-bit WAV minimum 44.1kHz." />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setRejectId(null)} className="btn-secondary flex-1">Cancel</button>
              <button
                onClick={handleReject}
                disabled={rejectMutation.isPending}
                className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-all text-sm font-medium">
                {rejectMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
