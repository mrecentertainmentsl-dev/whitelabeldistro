'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, Users, Music2, CheckSquare,
  Settings, FileText, LogOut, Headphones, Shield
} from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { useBranding } from '@/lib/branding-context';
import { clsx } from 'clsx';

const navItems = [
  { href: '/admin', label: 'Overview', icon: LayoutDashboard, exact: true },
  { href: '/admin/users', label: 'Users', icon: Users },
  { href: '/admin/releases', label: 'All Releases', icon: Music2 },
  { href: '/admin/approvals', label: 'Approvals', icon: CheckSquare },
  { href: '/admin/settings', label: 'Settings', icon: Settings },
  { href: '/admin/logs', label: 'System Logs', icon: FileText },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout, fetchMe } = useAuthStore();
  const branding = useBranding();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const init = async () => {
      if (!isAuthenticated) await fetchMe();
      const u = useAuthStore.getState().user;
      if (!u || u.role?.name !== 'admin') router.replace('/auth/login');
    };
    init().catch(() => router.replace('/auth/login'));
  }, []);

  if (!user || user.role?.name !== 'admin') return null;

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--color-background)' }}>
      {/* Sidebar */}
      <aside className="w-64 shrink-0 flex flex-col border-r border-[var(--color-surface-border)] bg-[var(--color-surface)]">
        <div className="h-16 flex items-center gap-3 px-5 border-b border-[var(--color-surface-border)]">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: 'var(--gradient-brand)' }}>
            <Headphones className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0">
            <p className="font-heading font-bold text-white text-sm truncate">{branding.platformName}</p>
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Shield className="w-3 h-3" /> Admin Panel
            </p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-0.5">
          {navItems.map(({ href, label, icon: Icon, exact }) => {
            const active = exact ? pathname === href : pathname.startsWith(href);
            return (
              <Link key={href} href={href} className={clsx('sidebar-link', active && 'active')}>
                <Icon className="w-4 h-4 shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-[var(--color-surface-border)]">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg">
            <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-sm font-bold text-white"
                 style={{ background: 'var(--gradient-brand)' }}>
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.displayName || user?.firstName}</p>
              <p className="text-xs text-gray-500">Administrator</p>
            </div>
            <button onClick={logout} className="text-gray-500 hover:text-red-400 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 flex items-center px-6 border-b border-[var(--color-surface-border)] bg-[var(--color-surface)]/50">
          <div className="flex items-center gap-1 text-sm text-gray-500">
            <span>Admin</span>
            <span className="mx-1 text-gray-700">/</span>
            <span className="text-white">
              {navItems.find(n => n.exact ? pathname === n.href : pathname.startsWith(n.href))?.label}
            </span>
          </div>
        </header>
        <div className="flex-1 overflow-auto p-6">{children}</div>
      </main>
    </div>
  );
}
