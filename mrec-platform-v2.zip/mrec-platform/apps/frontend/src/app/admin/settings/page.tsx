'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useDropzone } from 'react-dropzone';
import { toast } from 'react-hot-toast';
import { Save, Palette, Server, Mail, Globe, Upload, Loader2 } from 'lucide-react';
import { api } from '@/lib/api';

type Tab = 'branding' | 'storage' | 'email' | 'distribution' | 'domain';

const TABS: { id: Tab; label: string; icon: any }[] = [
  { id: 'branding', label: 'Branding', icon: Palette },
  { id: 'storage', label: 'Storage (AWS S3)', icon: Server },
  { id: 'email', label: 'Email (AWS SES)', icon: Mail },
  { id: 'distribution', label: 'Distribution', icon: Globe },
  { id: 'domain', label: 'Domains', icon: Globe },
];

export default function AdminSettingsPage() {
  const [tab, setTab] = useState<Tab>('branding');
  const qc = useQueryClient();

  const { data: branding } = useQuery({
    queryKey: ['admin-branding'],
    queryFn: () => api.get('/api/v1/branding').then(r => r.data[0] || {}),
  });

  const { data: settings } = useQuery({
    queryKey: ['admin-settings'],
    queryFn: () => api.get('/api/v1/settings').then(r => r.data),
  });

  const settingsMap: Record<string, string> = {};
  if (Array.isArray(settings)) settings.forEach((s: any) => { settingsMap[s.key] = s.value; });

  const updateBranding = useMutation({
    mutationFn: (dto: any) => api.put(`/api/v1/branding/default/update`, dto),
    onSuccess: () => { toast.success('Branding saved!'); qc.invalidateQueries({ queryKey: ['admin-branding'] }); },
    onError: () => toast.error('Save failed'),
  });

  const updateSettings = useMutation({
    mutationFn: (dto: Record<string, string>) => api.put('/api/v1/settings', dto),
    onSuccess: () => toast.success('Settings saved!'),
    onError: () => toast.error('Save failed'),
  });

  // ─── Branding form state ─────────────────────────────────────────────
  const [brandForm, setBrandForm] = useState({
    platformName: branding?.platformName || 'MREC Entertainment',
    tagline: branding?.tagline || '',
    primaryColor: branding?.primaryColor || '#7C3AED',
    secondaryColor: branding?.secondaryColor || '#A855F7',
    accentColor: branding?.accentColor || '#F59E0B',
    backgroundColor: branding?.backgroundColor || '#0A0A0F',
    supportEmail: branding?.supportEmail || '',
    footerText: branding?.footerText || '',
  });

  const [awsForm, setAwsForm] = useState({
    aws_access_key_id: '',
    aws_secret_access_key: '',
    aws_s3_bucket: settingsMap['aws_s3_bucket'] || '',
    aws_s3_region: settingsMap['aws_s3_region'] || 'us-east-1',
  });

  const [sesForm, setSesForm] = useState({
    aws_ses_region: settingsMap['aws_ses_region'] || 'us-east-1',
    aws_ses_from_email: settingsMap['aws_ses_from_email'] || '',
    aws_ses_from_name: settingsMap['aws_ses_from_name'] || '',
  });

  // Logo upload
  const onLogoDrop = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    const { data: presign } = await api.post('/api/v1/uploads/presign', {
      filename: file.name, contentType: file.type, uploadType: 'logo',
    });
    await fetch(presign.uploadUrl, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
    updateBranding.mutate({ logoUrl: presign.publicUrl, logoS3Key: presign.key });
    toast.success('Logo uploaded!');
  };

  const { getRootProps: getLRootProps, getInputProps: getLInputProps } = useDropzone({
    onDrop: onLogoDrop, accept: { 'image/png': ['.png'], 'image/jpeg': ['.jpg', '.jpeg'], 'image/svg+xml': ['.svg'] }, maxFiles: 1,
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">Platform Settings</h1>
        <p className="text-gray-400 mt-1">Configure branding, storage, email and distribution</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl bg-[var(--color-surface)] border border-[var(--color-surface-border)] w-fit">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    tab === id ? 'bg-[var(--color-surface-elevated)] text-white' : 'text-gray-500 hover:text-gray-300'
                  }`}>
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* ── BRANDING ─────────────────────────────────────────────────── */}
      {tab === 'branding' && (
        <div className="card p-6 space-y-6">
          <h2 className="font-heading font-semibold text-white">White Label Branding</h2>

          {/* Logo upload */}
          <div>
            <label className="label">Platform Logo</label>
            <div className="flex items-center gap-4">
              {branding?.logoUrl && <img src={branding.logoUrl} alt="Logo" className="h-12 object-contain rounded" />}
              <div {...getLRootProps()} className="dropzone flex-1 !py-5">
                <input {...getLInputProps()} />
                <Upload className="w-5 h-5 text-gray-500" />
                <p className="text-gray-400 text-sm">Upload logo (PNG, JPG, SVG)</p>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="label">Platform Name</label>
              <input className="input" value={brandForm.platformName}
                     onChange={e => setBrandForm(p => ({ ...p, platformName: e.target.value }))} />
            </div>
            <div>
              <label className="label">Tagline</label>
              <input className="input" value={brandForm.tagline} placeholder="e.g. Distribute Your Music Globally"
                     onChange={e => setBrandForm(p => ({ ...p, tagline: e.target.value }))} />
            </div>
          </div>

          {/* Colors */}
          <div>
            <label className="label">Brand Colors</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { key: 'primaryColor', label: 'Primary' },
                { key: 'secondaryColor', label: 'Secondary' },
                { key: 'accentColor', label: 'Accent' },
                { key: 'backgroundColor', label: 'Background' },
              ].map(({ key, label }) => (
                <div key={key} className="space-y-2">
                  <label className="text-xs text-gray-400">{label}</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={(brandForm as any)[key]}
                           onChange={e => setBrandForm(p => ({ ...p, [key]: e.target.value }))}
                           className="w-10 h-9 rounded border border-[var(--color-surface-border)] cursor-pointer bg-transparent p-0.5" />
                    <input className="input flex-1 font-mono text-sm" value={(brandForm as any)[key]}
                           onChange={e => setBrandForm(p => ({ ...p, [key]: e.target.value }))} />
                  </div>
                </div>
              ))}
            </div>

            {/* Live preview */}
            <div className="mt-4 p-4 rounded-xl border border-[var(--color-surface-border)]"
                 style={{ background: brandForm.backgroundColor }}>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                     style={{ background: `linear-gradient(135deg, ${brandForm.primaryColor}, ${brandForm.secondaryColor})` }}>
                  <span className="text-white text-xs font-bold">M</span>
                </div>
                <span className="font-bold text-white">{brandForm.platformName || 'Platform Name'}</span>
              </div>
              <button className="px-4 py-1.5 rounded-lg text-white text-sm font-medium"
                      style={{ background: `linear-gradient(135deg, ${brandForm.primaryColor}, ${brandForm.secondaryColor})` }}>
                Preview Button
              </button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="label">Support Email</label>
              <input className="input" type="email" value={brandForm.supportEmail} placeholder="support@yourplatform.com"
                     onChange={e => setBrandForm(p => ({ ...p, supportEmail: e.target.value }))} />
            </div>
            <div>
              <label className="label">Footer Text</label>
              <input className="input" value={brandForm.footerText} placeholder="© 2025 Your Platform"
                     onChange={e => setBrandForm(p => ({ ...p, footerText: e.target.value }))} />
            </div>
          </div>

          <button onClick={() => updateBranding.mutate(brandForm)}
                  disabled={updateBranding.isPending}
                  className="btn-primary flex items-center gap-2">
            {updateBranding.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Branding
          </button>
        </div>
      )}

      {/* ── AWS S3 ──────────────────────────────────────────────────── */}
      {tab === 'storage' && (
        <div className="card p-6 space-y-5">
          <div>
            <h2 className="font-heading font-semibold text-white">AWS S3 Configuration</h2>
            <p className="text-sm text-gray-400 mt-1">Files are uploaded directly to S3. Keys are encrypted at rest.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="label">Access Key ID</label>
              <input className="input font-mono" type="password" placeholder="AKIA••••••••••••••••"
                     value={awsForm.aws_access_key_id}
                     onChange={e => setAwsForm(p => ({ ...p, aws_access_key_id: e.target.value }))} />
            </div>
            <div>
              <label className="label">Secret Access Key</label>
              <input className="input font-mono" type="password" placeholder="••••••••••••••••••••••••••••••••••••••••"
                     value={awsForm.aws_secret_access_key}
                     onChange={e => setAwsForm(p => ({ ...p, aws_secret_access_key: e.target.value }))} />
            </div>
            <div>
              <label className="label">S3 Bucket Name</label>
              <input className="input font-mono" placeholder="my-platform-files"
                     value={awsForm.aws_s3_bucket}
                     onChange={e => setAwsForm(p => ({ ...p, aws_s3_bucket: e.target.value }))} />
            </div>
            <div>
              <label className="label">Region</label>
              <select className="input" value={awsForm.aws_s3_region}
                      onChange={e => setAwsForm(p => ({ ...p, aws_s3_region: e.target.value }))}>
                {['us-east-1','us-west-2','eu-west-1','eu-central-1','ap-southeast-1','ap-northeast-1'].map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
          </div>
          <button onClick={() => updateSettings.mutate(awsForm)}
                  disabled={updateSettings.isPending}
                  className="btn-primary flex items-center gap-2">
            {updateSettings.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Storage Config
          </button>
        </div>
      )}

      {/* ── AWS SES ─────────────────────────────────────────────────── */}
      {tab === 'email' && (
        <div className="card p-6 space-y-5">
          <div>
            <h2 className="font-heading font-semibold text-white">AWS SES Email Configuration</h2>
            <p className="text-sm text-gray-400 mt-1">Used for verification emails, release status notifications, etc.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="label">SES Region</label>
              <select className="input" value={sesForm.aws_ses_region}
                      onChange={e => setSesForm(p => ({ ...p, aws_ses_region: e.target.value }))}>
                {['us-east-1','us-west-2','eu-west-1','ap-southeast-1'].map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">From Email Address</label>
              <input className="input" type="email" placeholder="noreply@yourplatform.com"
                     value={sesForm.aws_ses_from_email}
                     onChange={e => setSesForm(p => ({ ...p, aws_ses_from_email: e.target.value }))} />
            </div>
            <div>
              <label className="label">From Name</label>
              <input className="input" placeholder="Your Platform Name"
                     value={sesForm.aws_ses_from_name}
                     onChange={e => setSesForm(p => ({ ...p, aws_ses_from_name: e.target.value }))} />
            </div>
          </div>
          <button onClick={() => updateSettings.mutate(sesForm)}
                  disabled={updateSettings.isPending}
                  className="btn-primary flex items-center gap-2">
            {updateSettings.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Email Config
          </button>
        </div>
      )}

      {/* ── DOMAIN ──────────────────────────────────────────────────── */}
      {tab === 'domain' && (
        <div className="card p-6 space-y-5">
          <div>
            <h2 className="font-heading font-semibold text-white">Custom Domain / CNAME</h2>
            <p className="text-sm text-gray-400 mt-1">
              Map a custom domain to this platform. Point your CNAME to{' '}
              <code className="font-mono text-purple-400">platform.mrec.io</code>
            </p>
          </div>
          <div className="p-4 rounded-xl border border-[var(--color-surface-border)] bg-[var(--color-surface-elevated)]">
            <h3 className="text-sm font-medium text-white mb-3">DNS Setup Instructions</h3>
            <ol className="text-sm text-gray-400 space-y-2 list-decimal list-inside">
              <li>Log into your DNS provider (Cloudflare, Route53, GoDaddy, etc.)</li>
              <li>Add a CNAME record: <code className="font-mono text-purple-400">music.yourdomain.com → platform.mrec.io</code></li>
              <li>Enter your domain below and click Verify</li>
              <li>SSL is provisioned automatically once verified</li>
            </ol>
          </div>
          <div className="flex gap-3">
            <input className="input flex-1" placeholder="music.yourdomain.com" />
            <button className="btn-primary shrink-0">Add Domain</button>
          </div>
          <p className="text-xs text-gray-500">
            Each domain can have its own branding configuration. Perfect for white-label clients.
          </p>
        </div>
      )}
    </div>
  );
}
