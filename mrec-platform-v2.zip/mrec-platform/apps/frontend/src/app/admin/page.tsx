'use client';

import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { Users, Music2, Clock, Globe, TrendingUp, ArrowRight, CheckCircle, XCircle } from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

const STATUS_MAP: Record<string, { label: string; cls: string }> = {
  pending: { label: 'Pending', cls: 'status-pending' },
  approved: { label: 'Approved', cls: 'status-approved' },
  rejected: { label: 'Rejected', cls: 'status-rejected' },
  draft: { label: 'Draft', cls: 'status-draft' },
  distributed: { label: 'Distributed', cls: 'status-distributed' },
};

function StatCard({ label, value, icon: Icon, color, sub }: any) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-gray-400">{label}</span>
        <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${color}20` }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
      </div>
      <p className="text-3xl font-heading font-bold text-white">{value ?? 0}</p>
      {sub && <p className="text-xs text-gray-500 mt-1">{sub}</p>}
    </div>
  );
}

export default function AdminOverviewPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin-overview'],
    queryFn: () => api.get('/api/v1/admin/overview').then(r => r.data),
    refetchInterval: 30000,
  });

  const stats = [
    { label: 'Total Users', value: data?.users?.total, icon: Users, color: '#7C3AED', sub: `+${data?.users?.newThisMonth ?? 0} this month` },
    { label: 'Total Releases', value: data?.releases?.total, icon: Music2, color: '#3B82F6' },
    { label: 'Pending Approval', value: data?.releases?.pending, icon: Clock, color: '#F59E0B', sub: 'Awaiting review' },
    { label: 'Distributed', value: data?.releases?.distributed, icon: Globe, color: '#10B981' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">Admin Overview</h1>
          <p className="text-gray-400 mt-1">Platform-wide statistics and activity</p>
        </div>
        <Link href="/admin/approvals" className="btn-primary flex items-center gap-2 text-sm">
          <Clock className="w-4 h-4" />
          Review Queue
          {data?.releases?.pending > 0 && (
            <span className="bg-white/20 text-white text-xs px-1.5 py-0.5 rounded-full">
              {data.releases.pending}
            </span>
          )}
        </Link>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      {/* Release status breakdown */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h3 className="font-heading font-semibold text-white mb-4">Release Status Breakdown</h3>
          <div className="space-y-3">
            {[
              { label: 'Draft', value: data?.releases?.total - data?.releases?.pending - data?.releases?.approved - data?.releases?.rejected - data?.releases?.distributed, color: '#6B7280' },
              { label: 'Pending', value: data?.releases?.pending, color: '#F59E0B' },
              { label: 'Approved', value: data?.releases?.approved, color: '#10B981' },
              { label: 'Rejected', value: data?.releases?.rejected, color: '#EF4444' },
              { label: 'Distributed', value: data?.releases?.distributed, color: '#3B82F6' },
            ].map(({ label, value, color }) => {
              const pct = data?.releases?.total > 0 ? ((value || 0) / data.releases.total) * 100 : 0;
              return (
                <div key={label}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-400">{label}</span>
                    <span className="text-white font-medium">{value ?? 0}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-[var(--color-surface-elevated)] overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--color-surface-border)]">
            <h3 className="font-heading font-semibold text-white">Recent Submissions</h3>
            <Link href="/admin/releases" className="text-sm flex items-center gap-1" style={{ color: 'var(--color-primary)' }}>
              View all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          {!data?.recentReleases?.length ? (
            <div className="p-8 text-center text-gray-500 text-sm">No releases yet</div>
          ) : (
            <div className="divide-y divide-[var(--color-surface-border)]">
              {data.recentReleases.map((r: any) => {
                const st = STATUS_MAP[r.status] || { label: r.status, cls: 'status-draft' };
                return (
                  <Link key={r.id} href={`/admin/releases/${r.id}`}
                        className="flex items-center gap-3 px-5 py-3 hover:bg-[var(--color-surface-elevated)] transition-colors">
                    <Music2 className="w-4 h-4 text-gray-500 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{r.title}</p>
                      <p className="text-xs text-gray-500 truncate">{r.user?.email}</p>
                    </div>
                    <span className={st.cls}>{st.label}</span>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
