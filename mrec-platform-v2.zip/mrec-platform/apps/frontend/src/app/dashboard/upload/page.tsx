'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useDropzone } from 'react-dropzone';
import { useForm } from 'react-hook-form';
import { toast } from 'react-hot-toast';
import {
  Upload, Music2, Image, CheckCircle, ChevronRight,
  ChevronLeft, Loader2, X, File
} from 'lucide-react';
import { api } from '@/lib/api';

const GENRES = ['Pop', 'Hip-Hop', 'R&B', 'Rock', 'Electronic', 'Jazz', 'Classical', 'Country', 'Latin', 'Gospel', 'Afrobeats', 'Reggae', 'Other'];
const LANGUAGES = ['English', 'Spanish', 'French', 'Portuguese', 'Yoruba', 'Igbo', 'Hausa', 'Arabic', 'Swahili', 'Other'];

type Step = 'release' | 'tracks' | 'artwork' | 'review';
const STEPS: { id: Step; label: string }[] = [
  { id: 'release', label: 'Release Info' },
  { id: 'tracks', label: 'Tracks' },
  { id: 'artwork', label: 'Artwork' },
  { id: 'review', label: 'Review & Submit' },
];

export default function UploadPage() {
  const [step, setStep] = useState<Step>('release');
  const [releaseId, setReleaseId] = useState<string | null>(null);
  const [songs, setSongs] = useState<any[]>([]);
  const [artwork, setArtwork] = useState<{ url: string; key: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadingAudio, setUploadingAudio] = useState<Record<string, boolean>>({});
  const router = useRouter();

  const { register, handleSubmit, getValues, formState: { errors } } = useForm({
    defaultValues: {
      title: '', type: 'single', genre: '', language: 'English',
      releaseDate: '', labelName: '', submissionNotes: '',
      distributionPlatforms: ['spotify', 'apple_music', 'youtube_music', 'tiktok', 'deezer'],
    },
  });

  const stepIndex = STEPS.findIndex(s => s.id === step);

  // ─── Step 1: Create release draft ───────────────────────────────────
  const saveRelease = handleSubmit(async (data) => {
    try {
      if (!releaseId) {
        const res = await api.post('/api/v1/releases', data);
        setReleaseId(res.data.id);
      } else {
        await api.put(`/api/v1/releases/${releaseId}`, data);
      }
      setStep('tracks');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to save release info');
    }
  });

  // ─── Step 2: Upload audio files ──────────────────────────────────────
  const onAudioDrop = useCallback(async (files: File[]) => {
    for (const file of files) {
      const tempId = crypto.randomUUID();
      setUploadingAudio(prev => ({ ...prev, [tempId]: true }));
      try {
        // 1. Get presigned URL
        const { data: presign } = await api.post('/api/v1/uploads/presign', {
          filename: file.name,
          contentType: file.type || 'audio/wav',
          uploadType: 'audio',
        });

        // 2. Upload directly to S3
        await fetch(presign.uploadUrl, {
          method: 'PUT',
          body: file,
          headers: { 'Content-Type': file.type || 'audio/wav' },
        });

        // 3. Create song record
        const songName = file.name.replace(/\.[^.]+$/, '');
        const { data: song } = await api.post(`/api/v1/releases/${releaseId}/songs`, {
          title: songName,
          artistName: getValues('title') || songName,
          audioUrl: presign.publicUrl,
          audioS3Key: presign.key,
          audioFormat: file.name.split('.').pop()?.toLowerCase(),
          audioSizeBytes: file.size,
        });

        setSongs(prev => [...prev, { ...song, filename: file.name, size: file.size }]);
        toast.success(`"${songName}" uploaded`);
      } catch (err: any) {
        toast.error(`Failed to upload ${file.name}`);
      } finally {
        setUploadingAudio(prev => { const n = { ...prev }; delete n[tempId]; return n; });
      }
    }
  }, [releaseId]);

  const audioDropzone = useDropzone({
    onDrop: onAudioDrop,
    accept: { 'audio/wav': ['.wav'], 'audio/flac': ['.flac'], 'audio/x-flac': ['.flac'] },
    maxSize: 500 * 1024 * 1024,
    disabled: !releaseId,
  });

  const removeSong = (id: string) => setSongs(prev => prev.filter(s => s.id !== id));

  // ─── Step 3: Upload artwork ──────────────────────────────────────────
  const onArtworkDrop = useCallback(async (files: File[]) => {
    const file = files[0];
    if (!file) return;

    // Check dimensions
    const img = document.createElement('img');
    const objUrl = URL.createObjectURL(file);
    img.src = objUrl;
    await new Promise(res => { img.onload = res; });
    URL.revokeObjectURL(objUrl);

    if (img.width < 3000 || img.height < 3000) {
      toast.error(`Artwork must be at least 3000×3000px. Yours is ${img.width}×${img.height}px.`);
      return;
    }

    try {
      const { data: presign } = await api.post('/api/v1/uploads/presign', {
        filename: file.name,
        contentType: file.type,
        uploadType: 'artwork',
      });

      await fetch(presign.uploadUrl, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
      await api.put(`/api/v1/releases/${releaseId}`, {
        artworkUrl: presign.publicUrl,
        artworkS3Key: presign.key,
      });

      setArtwork({ url: presign.publicUrl, key: presign.key });
      toast.success('Artwork uploaded!');
    } catch {
      toast.error('Artwork upload failed');
    }
  }, [releaseId]);

  const artworkDropzone = useDropzone({
    onDrop: onArtworkDrop,
    accept: { 'image/jpeg': ['.jpg', '.jpeg'], 'image/png': ['.png'] },
    maxFiles: 1,
    maxSize: 50 * 1024 * 1024,
  });

  // ─── Step 4: Submit ──────────────────────────────────────────────────
  const submitRelease = async () => {
    if (!releaseId) return;
    setIsSubmitting(true);
    try {
      await api.post(`/api/v1/releases/${releaseId}/submit`);
      toast.success('Release submitted for review! 🎉');
      router.push('/dashboard/releases');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const uploadingCount = Object.keys(uploadingAudio).length;

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-fade-in">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">Upload New Release</h1>
        <p className="text-gray-400 mt-1">Follow the steps to distribute your music globally</p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s.id} className="flex items-center gap-2">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
              i < stepIndex ? 'text-emerald-400' :
              i === stepIndex ? 'text-white' : 'text-gray-600'
            }`}>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                i < stepIndex ? 'bg-emerald-500/20 text-emerald-400' :
                i === stepIndex ? 'text-white' : 'bg-[var(--color-surface-elevated)] text-gray-600'
              }`} style={i === stepIndex ? { background: 'var(--gradient-brand)' } : {}}>
                {i < stepIndex ? <CheckCircle className="w-3.5 h-3.5" /> : i + 1}
              </span>
              {s.label}
            </div>
            {i < STEPS.length - 1 && <ChevronRight className="w-4 h-4 text-gray-700 shrink-0" />}
          </div>
        ))}
      </div>

      {/* ── Step 1: Release Info ─────────────────────────────────────── */}
      {step === 'release' && (
        <form onSubmit={saveRelease} className="card p-6 space-y-5">
          <h2 className="font-heading font-semibold text-white text-lg">Release Information</h2>
          <div>
            <label className="label">Release Title *</label>
            <input {...register('title', { required: 'Title is required' })} className="input" placeholder="e.g. My Amazing EP" />
            {errors.title && <p className="text-red-400 text-xs mt-1">{errors.title.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Release Type</label>
              <select {...register('type')} className="input">
                <option value="single">Single</option>
                <option value="ep">EP</option>
                <option value="album">Album</option>
                <option value="compilation">Compilation</option>
              </select>
            </div>
            <div>
              <label className="label">Genre</label>
              <select {...register('genre')} className="input">
                <option value="">Select genre</option>
                {GENRES.map(g => <option key={g} value={g.toLowerCase()}>{g}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Language</label>
              <select {...register('language')} className="input">
                {LANGUAGES.map(l => <option key={l} value={l.toLowerCase()}>{l}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Release Date</label>
              <input {...register('releaseDate')} type="date" className="input"
                     min={new Date().toISOString().split('T')[0]} />
            </div>
          </div>
          <div>
            <label className="label">Label Name <span className="text-gray-500">(optional)</span></label>
            <input {...register('labelName')} className="input" placeholder="Your label or self-released" />
          </div>
          <div>
            <label className="label">Notes for Review Team <span className="text-gray-500">(optional)</span></label>
            <textarea {...register('submissionNotes')} className="input h-24 resize-none" placeholder="Any special instructions..." />
          </div>
          <div className="flex justify-end">
            <button type="submit" className="btn-primary flex items-center gap-2">
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}

      {/* ── Step 2: Tracks ──────────────────────────────────────────── */}
      {step === 'tracks' && (
        <div className="card p-6 space-y-5">
          <h2 className="font-heading font-semibold text-white text-lg">Upload Tracks</h2>
          <p className="text-sm text-gray-400">Accepted formats: WAV, FLAC · Max 500MB per file</p>

          <div {...audioDropzone.getRootProps()} className={`dropzone ${audioDropzone.isDragActive ? 'active' : ''}`}>
            <input {...audioDropzone.getInputProps()} />
            <Music2 className="w-10 h-10 text-gray-600" />
            <p className="text-gray-400 font-medium text-center">Drop your audio files here</p>
            <p className="text-gray-500 text-sm text-center">or click to browse · WAV / FLAC only</p>
          </div>

          {uploadingCount > 0 && (
            <div className="flex items-center gap-3 text-sm text-gray-400 p-3 rounded-lg bg-[var(--color-surface-elevated)]">
              <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
              Uploading {uploadingCount} file{uploadingCount > 1 ? 's' : ''}...
            </div>
          )}

          {songs.length > 0 && (
            <div className="space-y-2">
              {songs.map((s, i) => (
                <div key={s.id} className="flex items-center gap-3 p-3 rounded-lg bg-[var(--color-surface-elevated)]">
                  <div className="w-8 h-8 rounded flex items-center justify-center shrink-0" style={{ background: 'rgba(124,58,237,0.2)' }}>
                    <Music2 className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{s.title}</p>
                    <p className="text-xs text-gray-500">{s.filename} · {(s.size / 1024 / 1024).toFixed(1)}MB</p>
                  </div>
                  <span className="text-xs text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> Uploaded
                  </span>
                  <button onClick={() => removeSong(s.id)} className="text-gray-600 hover:text-red-400 transition-colors">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-between">
            <button onClick={() => setStep('release')} className="btn-secondary flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" /> Back
            </button>
            <button onClick={() => { if (songs.length === 0) { toast.error('Add at least one track'); return; } setStep('artwork'); }}
                    className="btn-primary flex items-center gap-2">
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ── Step 3: Artwork ─────────────────────────────────────────── */}
      {step === 'artwork' && (
        <div className="card p-6 space-y-5">
          <h2 className="font-heading font-semibold text-white text-lg">Cover Artwork</h2>
          <p className="text-sm text-gray-400">Minimum 3000×3000px · JPG or PNG · Square format required</p>

          {artwork ? (
            <div className="flex items-center gap-4 p-4 rounded-xl bg-[var(--color-surface-elevated)]">
              <img src={artwork.url} alt="Artwork" className="w-20 h-20 rounded-lg object-cover" />
              <div className="flex-1">
                <p className="text-sm font-medium text-white">Artwork uploaded</p>
                <p className="text-xs text-gray-500 mt-0.5">3000×3000px minimum ✓</p>
              </div>
              <button onClick={() => setArtwork(null)} className="text-gray-500 hover:text-red-400 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div {...artworkDropzone.getRootProps()} className={`dropzone h-48 ${artworkDropzone.isDragActive ? 'active' : ''}`}>
              <input {...artworkDropzone.getInputProps()} />
              <Image className="w-10 h-10 text-gray-600" />
              <p className="text-gray-400 font-medium">Drop artwork here</p>
              <p className="text-gray-500 text-sm">JPG or PNG · 3000×3000px minimum</p>
            </div>
          )}

          <div className="flex justify-between">
            <button onClick={() => setStep('tracks')} className="btn-secondary flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" /> Back
            </button>
            <button onClick={() => { if (!artwork) { toast.error('Please upload artwork'); return; } setStep('review'); }}
                    className="btn-primary flex items-center gap-2">
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ── Step 4: Review ──────────────────────────────────────────── */}
      {step === 'review' && (
        <div className="card p-6 space-y-6">
          <h2 className="font-heading font-semibold text-white text-lg">Review & Submit</h2>
          <div className="flex gap-4">
            {artwork && <img src={artwork.url} alt="Artwork" className="w-24 h-24 rounded-xl object-cover shrink-0" />}
            <div>
              <p className="text-white font-semibold text-lg">{getValues('title')}</p>
              <p className="text-gray-400 text-sm capitalize">{getValues('type')} · {getValues('genre')} · {getValues('language')}</p>
              {getValues('releaseDate') && <p className="text-gray-500 text-xs mt-1">Release: {getValues('releaseDate')}</p>}
            </div>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-2">{songs.length} track{songs.length !== 1 ? 's' : ''}</p>
            {songs.map((s, i) => (
              <div key={s.id} className="flex items-center gap-3 py-2 border-b border-[var(--color-surface-border)] last:border-0">
                <span className="text-gray-600 text-sm w-5">{i + 1}</span>
                <Music2 className="w-4 h-4 text-gray-500 shrink-0" />
                <span className="text-sm text-white">{s.title}</span>
              </div>
            ))}
          </div>
          <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <p className="text-amber-400 text-sm font-medium mb-1">Before you submit</p>
            <p className="text-amber-200/70 text-xs">
              Once submitted, your release will be reviewed within 24-48 hours. Make sure all metadata is accurate — once distributed, title and artist changes require a takedown and re-upload.
            </p>
          </div>
          <div className="flex justify-between">
            <button onClick={() => setStep('artwork')} className="btn-secondary flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" /> Back
            </button>
            <button onClick={submitRelease} disabled={isSubmitting} className="btn-primary flex items-center gap-2">
              {isSubmitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Submitting...</> : <><CheckCircle className="w-4 h-4" /> Submit for Review</>}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
