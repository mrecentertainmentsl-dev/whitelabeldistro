'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'react-hot-toast';
import { useDropzone } from 'react-dropzone';
import { User, Lock, Bell, Save, Upload, Loader2, Eye, EyeOff } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';

type Tab = 'profile' | 'security' | 'notifications';

const profileSchema = z.object({
  firstName: z.string().min(1, 'Required'),
  lastName: z.string().min(1, 'Required'),
  displayName: z.string().optional(),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(1, 'Required'),
  newPassword: z.string().min(8, 'Min 8 characters').regex(/[A-Z]/).regex(/[0-9]/),
  confirmPassword: z.string(),
}).refine(d => d.newPassword === d.confirmPassword, {
  message: 'Passwords do not match', path: ['confirmPassword'],
});

export default function SettingsPage() {
  const [tab, setTab] = useState<Tab>('profile');
  const [avatarUrl, setAvatarUrl] = useState<string>('');
  const [showPwd, setShowPwd] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);
  const { user, fetchMe } = useAuthStore();

  const profileForm = useForm({ resolver: zodResolver(profileSchema), defaultValues: {
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    displayName: user?.displayName || '',
  }});

  const pwdForm = useForm({ resolver: zodResolver(passwordSchema) });

  const onAvatarDrop = async (files: File[]) => {
    const file = files[0];
    if (!file) return;
    try {
      const { data: presign } = await api.post('/api/v1/uploads/presign', {
        filename: file.name, contentType: file.type, uploadType: 'avatar',
      });
      await fetch(presign.uploadUrl, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
      await api.patch('/api/v1/users/me', { avatarUrl: presign.publicUrl });
      setAvatarUrl(presign.publicUrl);
      toast.success('Avatar updated!');
      fetchMe();
    } catch { toast.error('Failed to upload avatar'); }
  };

  const { getRootProps, getInputProps } = useDropzone({
    onDrop: onAvatarDrop,
    accept: { 'image/jpeg': ['.jpg', '.jpeg'], 'image/png': ['.png'] },
    maxFiles: 1, maxSize: 5 * 1024 * 1024,
  });

  const saveProfile = profileForm.handleSubmit(async (data) => {
    setSavingProfile(true);
    try {
      await api.patch('/api/v1/users/me', data);
      toast.success('Profile updated!');
      fetchMe();
    } catch { toast.error('Update failed'); }
    finally { setSavingProfile(false); }
  });

  const changePassword = pwdForm.handleSubmit(async (data) => {
    setSavingPwd(true);
    try {
      await api.post('/api/v1/auth/change-password', {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      toast.success('Password changed!');
      pwdForm.reset();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Password change failed');
    }
    finally { setSavingPwd(false); }
  });

  const TABS: { id: Tab; label: string; icon: any }[] = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Lock },
    { id: 'notifications', label: 'Notifications', icon: Bell },
  ];

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">Account Settings</h1>
        <p className="text-gray-400 mt-1">Manage your profile and account preferences</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 rounded-xl bg-[var(--color-surface)] border border-[var(--color-surface-border)] w-fit">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setTab(id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    tab === id ? 'bg-[var(--color-surface-elevated)] text-white' : 'text-gray-500 hover:text-gray-300'
                  }`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      {/* Profile tab */}
      {tab === 'profile' && (
        <div className="card p-6 space-y-6">
          {/* Avatar */}
          <div className="flex items-center gap-5">
            <div className="relative">
              {(avatarUrl || user?.avatarUrl) ? (
                <img src={avatarUrl || user?.avatarUrl} alt="Avatar"
                     className="w-20 h-20 rounded-full object-cover" />
              ) : (
                <div className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold text-white"
                     style={{ background: 'var(--gradient-brand)' }}>
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </div>
              )}
            </div>
            <div>
              <div {...getRootProps()} className="btn-secondary text-sm cursor-pointer flex items-center gap-2">
                <input {...getInputProps()} />
                <Upload className="w-4 h-4" /> Change Photo
              </div>
              <p className="text-xs text-gray-500 mt-2">JPG or PNG, max 5MB</p>
            </div>
          </div>

          <form onSubmit={saveProfile} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">First Name</label>
                <input {...profileForm.register('firstName')} className="input" />
                {profileForm.formState.errors.firstName && (
                  <p className="text-red-400 text-xs mt-1">{profileForm.formState.errors.firstName.message}</p>
                )}
              </div>
              <div>
                <label className="label">Last Name</label>
                <input {...profileForm.register('lastName')} className="input" />
              </div>
            </div>
            <div>
              <label className="label">Display Name <span className="text-gray-500">(shown publicly)</span></label>
              <input {...profileForm.register('displayName')} className="input" placeholder="Your artist or stage name" />
            </div>
            <div>
              <label className="label">Email Address</label>
              <input className="input opacity-50 cursor-not-allowed" value={user?.email || ''} disabled />
              <p className="text-xs text-gray-500 mt-1">Contact support to change your email.</p>
            </div>
            <button type="submit" disabled={savingProfile} className="btn-primary flex items-center gap-2">
              {savingProfile ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Profile
            </button>
          </form>
        </div>
      )}

      {/* Security tab */}
      {tab === 'security' && (
        <div className="card p-6 space-y-5">
          <h2 className="font-heading font-semibold text-white">Change Password</h2>
          <form onSubmit={changePassword} className="space-y-4">
            <div>
              <label className="label">Current Password</label>
              <input {...pwdForm.register('currentPassword')} type="password" className="input" placeholder="••••••••" />
              {pwdForm.formState.errors.currentPassword && (
                <p className="text-red-400 text-xs mt-1">{pwdForm.formState.errors.currentPassword.message}</p>
              )}
            </div>
            <div>
              <label className="label">New Password</label>
              <div className="relative">
                <input {...pwdForm.register('newPassword')} type={showPwd ? 'text' : 'password'} className="input pr-10" placeholder="••••••••" />
                <button type="button" onClick={() => setShowPwd(!showPwd)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                  {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {pwdForm.formState.errors.newPassword && (
                <p className="text-red-400 text-xs mt-1">{pwdForm.formState.errors.newPassword.message}</p>
              )}
            </div>
            <div>
              <label className="label">Confirm New Password</label>
              <input {...pwdForm.register('confirmPassword')} type="password" className="input" placeholder="••••••••" />
              {pwdForm.formState.errors.confirmPassword && (
                <p className="text-red-400 text-xs mt-1">{pwdForm.formState.errors.confirmPassword.message}</p>
              )}
            </div>
            <button type="submit" disabled={savingPwd} className="btn-primary flex items-center gap-2">
              {savingPwd ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              Change Password
            </button>
          </form>

          <div className="border-t border-[var(--color-surface-border)] pt-5">
            <h3 className="font-heading font-medium text-white mb-3">Account Info</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Member since</span>
                <span className="text-gray-300">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Email verified</span>
                <span className={user?.isEmailVerified ? 'text-emerald-400' : 'text-amber-400'}>
                  {user?.isEmailVerified ? '✓ Verified' : '⚠ Not verified'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Role</span>
                <span className="text-gray-300 capitalize">{user?.role?.name || 'artist'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Notifications tab */}
      {tab === 'notifications' && (
        <div className="card p-6 space-y-5">
          <h2 className="font-heading font-semibold text-white">Notification Preferences</h2>
          {[
            { label: 'Release approved', desc: 'When your release is approved for distribution', defaultOn: true },
            { label: 'Release rejected', desc: 'When your release is rejected with feedback', defaultOn: true },
            { label: 'Distribution live', desc: 'When your music goes live on platforms', defaultOn: true },
            { label: 'Platform updates', desc: 'Product news and platform announcements', defaultOn: false },
          ].map(({ label, desc, defaultOn }) => (
            <div key={label} className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-white">{label}</p>
                <p className="text-xs text-gray-500 mt-0.5">{desc}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-0.5">
                <input type="checkbox" className="sr-only peer" defaultChecked={defaultOn} />
                <div className="w-10 h-5 rounded-full peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all transition-all"
                     style={{ background: 'var(--color-surface-elevated)' }}
                     // Using inline style for peer-checked since we don't have full Tailwind JIT
                />
              </label>
            </div>
          ))}
          <button className="btn-primary flex items-center gap-2 text-sm">
            <Save className="w-4 h-4" /> Save Preferences
          </button>
        </div>
      )}
    </div>
  );
}
