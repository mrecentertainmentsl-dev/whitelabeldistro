'use client';

import { BarChart3, TrendingUp, Globe, Users, Lock } from 'lucide-react';

const PLATFORMS = [
  { name: 'Spotify', color: '#1DB954', streams: '—' },
  { name: 'Apple Music', color: '#FC3C44', streams: '—' },
  { name: 'YouTube Music', color: '#FF0000', streams: '—' },
  { name: 'TikTok', color: '#010101', streams: '—' },
  { name: 'Deezer', color: '#A238FF', streams: '—' },
];

export default function AnalyticsPage() {
  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">Analytics</h1>
        <p className="text-gray-400 mt-1">Track your streams, downloads, and revenue across all platforms</p>
      </div>

      {/* Coming soon banner */}
      <div className="card p-6 border-[var(--color-primary)]/30" style={{ background: 'linear-gradient(135deg, rgba(124,58,237,0.1), rgba(168,85,247,0.05))' }}>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'rgba(124,58,237,0.2)' }}>
            <BarChart3 className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
          </div>
          <div>
            <h2 className="font-heading font-semibold text-white mb-1">Analytics Dashboard — Coming Soon</h2>
            <p className="text-gray-400 text-sm">
              Once your music is distributed, you'll see real-time streams, listener demographics, revenue tracking, and per-platform breakdowns here.
            </p>
          </div>
        </div>
      </div>

      {/* Platform breakdown preview */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { label: 'Total Streams', icon: TrendingUp, color: '#7C3AED' },
          { label: 'Monthly Listeners', icon: Users, color: '#3B82F6' },
          { label: 'Countries Reached', icon: Globe, color: '#10B981' },
        ].map(({ label, icon: Icon, color }) => (
          <div key={label} className="card p-5 relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-gray-400">{label}</span>
              <Icon className="w-4 h-4" style={{ color }} />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-heading font-bold text-gray-600">—</span>
              <Lock className="w-4 h-4 text-gray-700" />
            </div>
            <p className="text-xs text-gray-600 mt-1">Available after distribution</p>
          </div>
        ))}
      </div>

      {/* Platform table */}
      <div className="card overflow-hidden">
        <div className="px-5 py-4 border-b border-[var(--color-surface-border)]">
          <h3 className="font-heading font-semibold text-white">Platform Breakdown</h3>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[var(--color-surface-border)]">
              {['Platform', 'Streams', 'Revenue', 'Status'].map(h => (
                <th key={h} className="px-5 py-3 text-left text-xs text-gray-500 uppercase tracking-wider font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--color-surface-border)]">
            {PLATFORMS.map(p => (
              <tr key={p.name} className="hover:bg-[var(--color-surface-elevated)] transition-colors">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: p.color }} />
                    <span className="text-white font-medium">{p.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-gray-600 font-mono">—</td>
                <td className="px-5 py-3 text-gray-600 font-mono">—</td>
                <td className="px-5 py-3">
                  <span className="badge bg-gray-500/15 text-gray-500 border border-gray-500/20">Pending distribution</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-center text-gray-600 text-sm">
        Analytics data will populate automatically once your releases are distributed.
      </p>
    </div>
  );
}
