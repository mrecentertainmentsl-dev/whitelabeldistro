'use client';

import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { Music2, Clock, CheckCircle, XCircle, Upload, Globe, ArrowRight, TrendingUp } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuthStore } from '@/store/auth.store';
import { format } from 'date-fns';

function StatCard({ label, value, icon: Icon, color }: any) {
  return (
    <div className="card p-5 flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}20` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div>
        <p className="text-2xl font-heading font-bold text-white">{value ?? '—'}</p>
        <p className="text-sm text-gray-400">{label}</p>
      </div>
    </div>
  );
}

const statusConfig: Record<string, { label: string; cls: string }> = {
  draft: { label: 'Draft', cls: 'status-draft' },
  pending: { label: 'Pending Review', cls: 'status-pending' },
  approved: { label: 'Approved', cls: 'status-approved' },
  rejected: { label: 'Rejected', cls: 'status-rejected' },
  distributed: { label: 'Distributed', cls: 'status-distributed' },
};

export default function DashboardPage() {
  const { user } = useAuthStore();

  const { data: stats } = useQuery({
    queryKey: ['release-stats'],
    queryFn: () => api.get('/api/v1/releases/stats').then(r => r.data),
  });

  const { data: releases } = useQuery({
    queryKey: ['releases', 1],
    queryFn: () => api.get('/api/v1/releases?limit=5').then(r => r.data),
  });

  const statCards = [
    { label: 'Total Releases', value: stats?.total ?? 0, icon: Music2, color: '#7C3AED' },
    { label: 'Pending Review', value: stats?.pending ?? 0, icon: Clock, color: '#F59E0B' },
    { label: 'Approved', value: stats?.approved ?? 0, icon: CheckCircle, color: '#10B981' },
    { label: 'Distributed', value: stats?.distributed ?? 0, icon: Globe, color: '#3B82F6' },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Greeting */}
      <div>
        <h1 className="font-heading text-2xl font-bold text-white">
          Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 17 ? 'afternoon' : 'evening'},{' '}
          {user?.firstName} 👋
        </h1>
        <p className="text-gray-400 mt-1">Here&apos;s what&apos;s happening with your music.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(c => <StatCard key={c.label} {...c} />)}
      </div>

      {/* Analytics placeholder */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" style={{ color: 'var(--color-primary)' }} />
            <h3 className="font-heading font-semibold text-white">Stream Analytics</h3>
          </div>
          <span className="badge bg-purple-500/15 text-purple-400 border border-purple-500/20">Coming Soon</span>
        </div>
        <div className="h-40 flex flex-col items-center justify-center gap-2 border border-dashed border-[var(--color-surface-border)] rounded-lg">
          <TrendingUp className="w-8 h-8 text-gray-600" />
          <p className="text-gray-500 text-sm">Analytics will appear here after your first distribution</p>
        </div>
      </div>

      {/* Recent releases */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--color-surface-border)]">
          <h3 className="font-heading font-semibold text-white">Recent Releases</h3>
          <Link href="/dashboard/releases" className="text-sm flex items-center gap-1 hover:opacity-80 transition-opacity" style={{ color: 'var(--color-primary)' }}>
            View all <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {!releases?.data?.length ? (
          <div className="py-16 flex flex-col items-center gap-3">
            <Upload className="w-10 h-10 text-gray-600" />
            <p className="text-gray-400 font-medium">No releases yet</p>
            <p className="text-gray-500 text-sm">Upload your first track to get started</p>
            <Link href="/dashboard/upload" className="btn-primary mt-2 text-sm">Upload Music</Link>
          </div>
        ) : (
          <div className="divide-y divide-[var(--color-surface-border)]">
            {releases.data.map((r: any) => {
              const st = statusConfig[r.status] || { label: r.status, cls: 'status-draft' };
              return (
                <Link key={r.id} href={`/dashboard/releases/${r.id}`}
                      className="flex items-center gap-4 px-5 py-3.5 hover:bg-[var(--color-surface-elevated)] transition-colors">
                  {r.artworkUrl ? (
                    <img src={r.artworkUrl} alt={r.title} className="w-10 h-10 rounded-lg object-cover" />
                  ) : (
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: 'rgba(124,58,237,0.2)' }}>
                      <Music2 className="w-4 h-4 text-purple-400" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{r.title}</p>
                    <p className="text-xs text-gray-500">{r.songs?.length ?? 0} track{r.songs?.length !== 1 ? 's' : ''} • {r.type}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className={st.cls}>{st.label}</span>
                    <span className="text-xs text-gray-500">{format(new Date(r.createdAt), 'MMM d')}</span>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-2 gap-4">
        <Link href="/dashboard/upload" className="card p-5 flex items-center gap-4 hover:border-[var(--color-primary)]/40 transition-all group">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'rgba(124,58,237,0.15)' }}>
            <Upload className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
          </div>
          <div>
            <p className="font-medium text-white group-hover:text-[var(--color-primary)] transition-colors">Upload New Release</p>
            <p className="text-sm text-gray-500">WAV or FLAC · Any genre</p>
          </div>
          <ArrowRight className="w-4 h-4 text-gray-600 ml-auto group-hover:text-[var(--color-primary)] transition-colors" />
        </Link>
        <Link href="/dashboard/settings" className="card p-5 flex items-center gap-4 hover:border-[var(--color-primary)]/40 transition-all group">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'rgba(16,185,129,0.15)' }}>
            <Globe className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <p className="font-medium text-white group-hover:text-emerald-400 transition-colors">Artist Profile</p>
            <p className="text-sm text-gray-500">Complete your profile</p>
          </div>
          <ArrowRight className="w-4 h-4 text-gray-600 ml-auto group-hover:text-emerald-400 transition-colors" />
        </Link>
      </div>
    </div>
  );
}
