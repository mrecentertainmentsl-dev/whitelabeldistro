'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, Music2, Upload, BarChart3,
  Settings, LogOut, Headphones, Bell, ChevronRight
} from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { useBranding } from '@/lib/branding-context';
import { clsx } from 'clsx';

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, exact: true },
  { href: '/dashboard/releases', label: 'My Releases', icon: Music2 },
  { href: '/dashboard/upload', label: 'Upload Music', icon: Upload },
  { href: '/dashboard/analytics', label: 'Analytics', icon: BarChart3 },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, logout, fetchMe } = useAuthStore();
  const branding = useBranding();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isAuthenticated) {
      fetchMe().catch(() => router.replace('/auth/login'));
    }
  }, []);

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--color-background)' }}>
      {/* Sidebar */}
      <aside className="w-64 shrink-0 flex flex-col border-r border-[var(--color-surface-border)] bg-[var(--color-surface)]">
        {/* Logo */}
        <div className="h-16 flex items-center gap-3 px-5 border-b border-[var(--color-surface-border)]">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
               style={{ background: 'var(--gradient-brand)' }}>
            <Headphones className="w-4 h-4 text-white" />
          </div>
          <span className="font-heading font-bold text-white text-sm truncate">
            {branding.platformName}
          </span>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5">
          {navItems.map(({ href, label, icon: Icon, exact }) => {
            const active = exact ? pathname === href : pathname.startsWith(href);
            return (
              <Link key={href} href={href}
                    className={clsx('sidebar-link', active && 'active')}>
                <Icon className="w-4 h-4 shrink-0" />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* User */}
        <div className="p-3 border-t border-[var(--color-surface-border)]">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-lg">
            <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-sm font-semibold text-white"
                 style={{ background: 'var(--gradient-brand)' }}>
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">{user?.displayName || user?.firstName}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
            <button onClick={logout} className="text-gray-500 hover:text-red-400 transition-colors" title="Sign out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-16 flex items-center justify-between px-6 border-b border-[var(--color-surface-border)] bg-[var(--color-surface)]/50 backdrop-blur-sm">
          <div className="flex items-center gap-1 text-sm text-gray-500">
            {navItems.find(n => (n.exact ? pathname === n.href : pathname.startsWith(n.href)))?.label && (
              <>
                <span>Home</span>
                <ChevronRight className="w-3 h-3" />
                <span className="text-white">
                  {navItems.find(n => (n.exact ? pathname === n.href : pathname.startsWith(n.href)))?.label}
                </span>
              </>
            )}
          </div>
          <div className="flex items-center gap-3">
            <button className="w-9 h-9 flex items-center justify-center rounded-lg text-gray-400 hover:text-white hover:bg-[var(--color-surface-elevated)] transition-all">
              <Bell className="w-4 h-4" />
            </button>
            <Link href="/dashboard/upload" className="btn-primary text-sm flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5" /> Upload
            </Link>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </main>
    </div>
  );
}
