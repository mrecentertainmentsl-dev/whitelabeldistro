'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { Music2, Upload, Search, Filter, ArrowRight, Clock, CheckCircle, XCircle, Globe, FileEdit } from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

const STATUS_OPTIONS = ['all', 'draft', 'pending', 'approved', 'rejected', 'distributed'];

const STATUS_CONFIG: Record<string, { label: string; cls: string; icon: any }> = {
  draft:       { label: 'Draft',       cls: 'status-draft',       icon: FileEdit },
  pending:     { label: 'Pending',     cls: 'status-pending',     icon: Clock },
  approved:    { label: 'Approved',    cls: 'status-approved',    icon: CheckCircle },
  rejected:    { label: 'Rejected',    cls: 'status-rejected',    icon: XCircle },
  distributed: { label: 'Distributed', cls: 'status-distributed', icon: Globe },
  processing:  { label: 'Processing',  cls: 'status-pending',     icon: Clock },
};

export default function ReleasesPage() {
  const [status, setStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useQuery({
    queryKey: ['releases', status, page],
    queryFn: () =>
      api.get(`/api/v1/releases?limit=12&page=${page}${status !== 'all' ? `&status=${status}` : ''}`).then(r => r.data),
  });

  const releases = data?.data || [];
  const total = data?.total || 0;

  const filtered = search
    ? releases.filter((r: any) => r.title.toLowerCase().includes(search.toLowerCase()))
    : releases;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold text-white">My Releases</h1>
          <p className="text-gray-400 mt-1">{total} total release{total !== 1 ? 's' : ''}</p>
        </div>
        <Link href="/dashboard/upload" className="btn-primary flex items-center gap-2 text-sm">
          <Upload className="w-4 h-4" /> New Release
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            className="input pl-9"
            placeholder="Search releases…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {STATUS_OPTIONS.map(s => (
            <button
              key={s}
              onClick={() => { setStatus(s); setPage(1); }}
              className={`px-3 py-2 rounded-lg text-xs font-medium capitalize transition-all border ${
                status === s
                  ? 'text-white border-transparent'
                  : 'text-gray-400 border-[var(--color-surface-border)] hover:text-white bg-[var(--color-surface)]'
              }`}
              style={status === s ? { background: 'var(--gradient-brand)', borderColor: 'transparent' } : {}}
            >
              {s === 'all' ? 'All' : STATUS_CONFIG[s]?.label || s}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="card p-4 space-y-3">
              <div className="skeleton w-full h-40 rounded-lg" />
              <div className="skeleton h-4 w-3/4" />
              <div className="skeleton h-3 w-1/2" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="card py-20 flex flex-col items-center gap-4">
          <Music2 className="w-12 h-12 text-gray-600" />
          <div className="text-center">
            <p className="font-medium text-gray-300 mb-1">No releases found</p>
            <p className="text-gray-500 text-sm">
              {status !== 'all' ? `No ${status} releases yet.` : "You haven't uploaded any music yet."}
            </p>
          </div>
          <Link href="/dashboard/upload" className="btn-primary text-sm mt-2">Upload Your First Release</Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r: any) => {
            const st = STATUS_CONFIG[r.status] || STATUS_CONFIG.draft;
            const Icon = st.icon;
            return (
              <Link key={r.id} href={`/dashboard/releases/${r.id}`}
                    className="card p-4 hover:border-[var(--color-primary)]/40 transition-all duration-200 group flex flex-col gap-3">
                {/* Artwork */}
                <div className="w-full aspect-square rounded-lg overflow-hidden bg-[var(--color-surface-elevated)] flex items-center justify-center">
                  {r.artworkUrl ? (
                    <img src={r.artworkUrl} alt={r.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  ) : (
                    <Music2 className="w-10 h-10 text-gray-600" />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1">
                  <h3 className="font-heading font-semibold text-white truncate group-hover:text-[var(--color-primary)] transition-colors">
                    {r.title}
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5 capitalize">
                    {r.type} · {r.songs?.length ?? 0} track{r.songs?.length !== 1 ? 's' : ''}
                    {r.genre ? ` · ${r.genre}` : ''}
                  </p>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between">
                  <span className={st.cls}><Icon className="w-3 h-3 mr-1 inline" />{st.label}</span>
                  <span className="text-xs text-gray-600">{format(new Date(r.createdAt), 'MMM d, yyyy')}</span>
                </div>

                {/* Rejection reason */}
                {r.status === 'rejected' && r.rejectedReason && (
                  <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/20">
                    <p className="text-xs text-red-400 leading-relaxed">{r.rejectedReason}</p>
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {total > 12 && (
        <div className="flex items-center justify-center gap-3">
          <button disabled={page === 1} onClick={() => setPage(p => p - 1)}
                  className="btn-secondary text-sm px-4 py-2 disabled:opacity-40">Previous</button>
          <span className="text-sm text-gray-400">Page {page} of {Math.ceil(total / 12)}</span>
          <button disabled={page * 12 >= total} onClick={() => setPage(p => p + 1)}
                  className="btn-secondary text-sm px-4 py-2 disabled:opacity-40">Next</button>
        </div>
      )}
    </div>
  );
}
