'use client';

import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  Music2, Clock, CheckCircle, XCircle, Globe,
  ArrowLeft, Calendar, Tag, Globe2, Disc, User, Mic2
} from 'lucide-react';
import { api } from '@/lib/api';
import { format } from 'date-fns';

const STATUS_CONFIG: Record<string, { label: string; cls: string; icon: any; description: string }> = {
  draft:       { label: 'Draft',       cls: 'status-draft',       icon: Disc,        description: 'Not submitted yet. Edit and submit when ready.' },
  pending:     { label: 'Pending Review', cls: 'status-pending',  icon: Clock,       description: 'Under review. You\'ll be notified within 24-48 hours.' },
  approved:    { label: 'Approved',    cls: 'status-approved',    icon: CheckCircle, description: 'Approved and queued for distribution.' },
  rejected:    { label: 'Rejected',    cls: 'status-rejected',    icon: XCircle,     description: 'Review the feedback and resubmit a corrected version.' },
  distributed: { label: 'Distributed', cls: 'status-distributed', icon: Globe,       description: 'Live on all selected platforms.' },
  processing:  { label: 'Processing',  cls: 'status-pending',     icon: Clock,       description: 'Being prepared for distribution.' },
};

function MetaRow({ icon: Icon, label, value }: { icon: any; label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-3">
      <Icon className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
      <div>
        <p className="text-xs text-gray-500">{label}</p>
        <p className="text-sm text-white capitalize">{value}</p>
      </div>
    </div>
  );
}

export default function ReleaseDetailPage() {
  const { id } = useParams();

  const { data: release, isLoading } = useQuery({
    queryKey: ['release', id],
    queryFn: () => api.get(`/api/v1/releases/${id}`).then(r => r.data),
  });

  if (isLoading) {
    return (
      <div className="space-y-4 animate-fade-in">
        <div className="skeleton h-8 w-48" />
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="skeleton aspect-square rounded-xl" />
          <div className="lg:col-span-2 space-y-4">
            <div className="skeleton h-8 w-3/4" />
            <div className="skeleton h-4 w-1/2" />
            <div className="skeleton h-32" />
          </div>
        </div>
      </div>
    );
  }

  if (!release) return <div className="text-gray-400">Release not found.</div>;

  const st = STATUS_CONFIG[release.status] || STATUS_CONFIG.draft;
  const StatusIcon = st.icon;

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl">
      {/* Back */}
      <Link href="/dashboard/releases" className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Releases
      </Link>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Artwork */}
        <div className="space-y-4">
          <div className="aspect-square rounded-xl overflow-hidden bg-[var(--color-surface-elevated)] flex items-center justify-center">
            {release.artworkUrl ? (
              <img src={release.artworkUrl} alt={release.title} className="w-full h-full object-cover" />
            ) : (
              <Music2 className="w-16 h-16 text-gray-600" />
            )}
          </div>

          {/* Status card */}
          <div className="card p-4">
            <div className="flex items-center gap-2 mb-2">
              <StatusIcon className="w-4 h-4" style={{ color: release.status === 'approved' || release.status === 'distributed' ? '#10B981' : release.status === 'rejected' ? '#EF4444' : '#F59E0B' }} />
              <span className={st.cls}>{st.label}</span>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">{st.description}</p>
            {release.status === 'rejected' && release.rejectedReason && (
              <div className="mt-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <p className="text-xs text-red-400 font-medium mb-1">Reason:</p>
                <p className="text-xs text-red-300 leading-relaxed">{release.rejectedReason}</p>
              </div>
            )}
            {release.adminNotes && release.status === 'approved' && (
              <div className="mt-3 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <p className="text-xs text-emerald-400">{release.adminNotes}</p>
              </div>
            )}
          </div>

          {/* Metadata */}
          <div className="card p-4 space-y-3">
            <MetaRow icon={Tag} label="Genre" value={release.genre} />
            <MetaRow icon={Globe2} label="Language" value={release.language} />
            <MetaRow icon={Calendar} label="Release Date" value={release.releaseDate ? format(new Date(release.releaseDate), 'MMMM d, yyyy') : null} />
            <MetaRow icon={User} label="Label" value={release.labelName} />
            <MetaRow icon={Tag} label="UPC" value={release.upc} />
            <MetaRow icon={Calendar} label="Submitted" value={release.submittedAt ? format(new Date(release.submittedAt), 'MMM d, yyyy HH:mm') : null} />
          </div>

          {/* Distribution platforms */}
          {release.distributionPlatforms?.length > 0 && (
            <div className="card p-4">
              <p className="text-xs text-gray-500 mb-3 uppercase tracking-wider">Platforms</p>
              <div className="flex flex-wrap gap-2">
                {release.distributionPlatforms.map((p: string) => (
                  <span key={p} className="px-2.5 py-1 rounded-full bg-[var(--color-surface-elevated)] text-xs text-gray-300 capitalize border border-[var(--color-surface-border)]">
                    {p.replace(/_/g, ' ')}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main content */}
        <div className="lg:col-span-2 space-y-5">
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-wider mb-1 capitalize">{release.type}</p>
            <h1 className="font-heading text-3xl font-bold text-white">{release.title}</h1>
          </div>

          {/* Track list */}
          <div className="card overflow-hidden">
            <div className="px-4 py-3 border-b border-[var(--color-surface-border)]">
              <h3 className="font-heading font-semibold text-white text-sm">
                {release.songs?.length ?? 0} Track{release.songs?.length !== 1 ? 's' : ''}
              </h3>
            </div>

            {!release.songs?.length ? (
              <div className="py-10 text-center text-gray-500 text-sm">No tracks added</div>
            ) : (
              <div className="divide-y divide-[var(--color-surface-border)]">
                {release.songs.map((s: any, i: number) => (
                  <div key={s.id} className="flex items-center gap-4 px-4 py-3 hover:bg-[var(--color-surface-elevated)] transition-colors">
                    <span className="text-gray-600 text-sm w-5 text-right shrink-0">{i + 1}</span>
                    <div className="w-8 h-8 rounded flex items-center justify-center shrink-0" style={{ background: 'rgba(124,58,237,0.15)' }}>
                      <Music2 className="w-4 h-4 text-purple-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white truncate">{s.title}</p>
                      <div className="flex flex-wrap gap-2 mt-0.5">
                        {s.artistName && <span className="text-xs text-gray-500">{s.artistName}</span>}
                        {s.featuredArtists?.length > 0 && (
                          <span className="text-xs text-gray-500">feat. {s.featuredArtists.join(', ')}</span>
                        )}
                        {s.isExplicit && (
                          <span className="px-1.5 py-0 rounded text-xs bg-red-500/20 text-red-400 border border-red-500/20">E</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0 space-y-0.5">
                      {s.isrc && <p className="text-xs text-gray-600 font-mono">{s.isrc}</p>}
                      {s.durationSeconds && (
                        <p className="text-xs text-gray-600">
                          {Math.floor(s.durationSeconds / 60)}:{String(s.durationSeconds % 60).padStart(2, '0')}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            {release.status === 'draft' && (
              <>
                <Link href={`/dashboard/upload?edit=${release.id}`} className="btn-secondary flex items-center gap-2 text-sm">
                  Edit Release
                </Link>
                <button className="btn-primary text-sm">Submit for Review</button>
              </>
            )}
            {release.status === 'rejected' && (
              <Link href={`/dashboard/upload?edit=${release.id}`} className="btn-primary text-sm flex items-center gap-2">
                Fix & Resubmit
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
