'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { api } from '@/lib/api';

export default function VerifyEmailPage() {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');
  const searchParams = useSearchParams();
  const token = searchParams.get('token');

  useEffect(() => {
    if (!token) { setStatus('error'); setMessage('Invalid verification link.'); return; }
    api.post(`/api/v1/auth/verify-email/${token}`)
      .then(res => { setStatus('success'); setMessage(res.data.message); })
      .catch(err => { setStatus('error'); setMessage(err.response?.data?.message || 'Verification failed.'); });
  }, [token]);

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ background: 'var(--color-background)' }}>
      <div className="card max-w-md w-full p-10 text-center">
        {status === 'loading' && (
          <>
            <Loader2 className="w-10 h-10 animate-spin text-purple-400 mx-auto mb-4" />
            <h2 className="font-heading text-xl font-bold text-white">Verifying your email…</h2>
          </>
        )}
        {status === 'success' && (
          <>
            <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-emerald-400" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-white mb-3">Email verified!</h2>
            <p className="text-gray-400 mb-8">{message}</p>
            <Link href="/auth/login" className="btn-primary px-8 py-2.5">Sign In Now</Link>
          </>
        )}
        {status === 'error' && (
          <>
            <div className="w-16 h-16 rounded-full bg-red-500/15 flex items-center justify-center mx-auto mb-6">
              <XCircle className="w-8 h-8 text-red-400" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-white mb-3">Verification failed</h2>
            <p className="text-gray-400 mb-8">{message}</p>
            <Link href="/auth/register" className="btn-secondary px-8 py-2.5">Register Again</Link>
          </>
        )}
      </div>
    </div>
  );
}
